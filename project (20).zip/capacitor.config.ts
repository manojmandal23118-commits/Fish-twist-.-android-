
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.tidetwist.game',
  appName: 'Tide Twist',
  webDir: 'out',
  bundledWebRuntime: false,
  plugins: {
    ScreenOrientation: {
      orientation: 'landscape'
    }
  }
};

export default config;
