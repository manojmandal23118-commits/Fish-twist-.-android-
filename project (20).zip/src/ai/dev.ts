import { config } from 'dotenv';
config();

import '@/ai/flows/ai-video-tagging.ts';