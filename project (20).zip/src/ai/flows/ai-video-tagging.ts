'use server';
/**
 * @fileOverview An AI agent for suggesting tags, keywords, and categorizations for videos.
 *
 * - aiVideoTagging - A function that handles the video tagging process.
 * - AiVideoTaggingInput - The input type for the aiVideoTagging function.
 * - AiVideoTaggingOutput - The return type for the aiVideoTagging function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiVideoTaggingInputSchema = z.object({
  videoDescription: z.string().describe('A textual description of the video content.'),
});
export type AiVideoTaggingInput = z.infer<typeof AiVideoTaggingInputSchema>;

const AiVideoTaggingOutputSchema = z.object({
  tags: z.array(z.string()).describe('A list of relevant tags for the video.'),
  keywords: z.array(z.string()).describe('A list of descriptive keywords for the video.'),
  categories: z.array(z.string()).describe('A list of categories the video belongs to.'),
});
export type AiVideoTaggingOutput = z.infer<typeof AiVideoTaggingOutputSchema>;

export async function aiVideoTagging(
  input: AiVideoTaggingInput
): Promise<AiVideoTaggingOutput> {
  return aiVideoTaggingFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiVideoTaggingPrompt',
  input: {schema: AiVideoTaggingInputSchema},
  output: {schema: AiVideoTaggingOutputSchema},
  prompt: `You are an AI assistant specialized in content categorization and tagging for video platforms. Your task is to analyze the provided video description and generate relevant tags, keywords, and categories.

The goal is to help organize the video content efficiently and improve its discoverability for viewers.

-   **Tags**: Short, descriptive labels that capture key aspects.
-   **Keywords**: More specific terms that users might search for.
-   **Categories**: Broader classifications for grouping similar content.

Video Description: {{{videoDescription}}}`,
});

const aiVideoTaggingFlow = ai.defineFlow(
  {
    name: 'aiVideoTaggingFlow',
    inputSchema: AiVideoTaggingInputSchema,
    outputSchema: AiVideoTaggingOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
