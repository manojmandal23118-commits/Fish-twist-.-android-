
import { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Tide Twist',
    short_name: 'Tide Twist',
    description: 'A magical underwater Butterfly Fish adventure!',
    start_url: '/',
    display: 'standalone',
    orientation: 'landscape',
    background_color: '#0c222d',
    theme_color: '#0c222d',
    icons: [
      {
        src: 'https://picsum.photos/seed/fish/192/192',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://picsum.photos/seed/fish/512/512',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  };
}
