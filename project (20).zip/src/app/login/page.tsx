
export default function LoginPage() {
  return <div className="p-8">Login page cleared.</div>;
}
