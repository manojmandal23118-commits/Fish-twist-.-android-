
export default function UploadPage() {
  return <div className="p-8">Upload page cleared.</div>;
}
