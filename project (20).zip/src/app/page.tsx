
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { GAME_MAPS } from '@/lib/game/levels';
import TideTwist from '@/components/game/tide-twist';
import { HomeScreen } from '@/components/game/ui/home-screen';
import { FishCollection } from '@/components/game/ui/fish-collection';
import { LevelSelector } from '@/components/game/ui/level-selector';
import { Button } from '@/components/ui/button';
import { Volume2, VolumeX, RotateCcw, Shield, LogOut } from 'lucide-react';
import { FishSkinId, SKIN_DATA } from '@/lib/game/types';
import { audio } from '@/lib/game/audio';
import { CoinIcon } from '@/components/game/ui/coin-icon';
import { App } from '@capacitor/app';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

type Screen = 'HOME' | 'LEVELS' | 'FISH' | 'SETTINGS' | 'PLAY';

export default function Home() {
  const [screen, setScreen] = useState<Screen>('HOME');
  const [selectedLevel, setSelectedLevel] = useState(1);
  const [selectedSkin, setSelectedSkin] = useState<FishSkinId>('fish_1');
  const [coins, setCoins] = useState(500);
  const [unlockedLevel, setUnlockedLevel] = useState(1);
  const [unlockedSkins, setUnlockedSkins] = useState<FishSkinId[]>(['fish_1']);
  const [isMuted, setIsMuted] = useState(false);
  const [isPortrait, setIsPortrait] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isExitDialogOpen, setIsExitDialogOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
    const checkOrientation = () => setIsPortrait(window.innerHeight > window.innerWidth);
    window.addEventListener('resize', checkOrientation);
    checkOrientation();
    return () => window.removeEventListener('resize', checkOrientation);
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedCoins = localStorage.getItem("tide_coins");
      const savedSkins = localStorage.getItem("tide_skins");
      const currentSkin = localStorage.getItem("tide_current_skin");
      const savedLevel = localStorage.getItem("tide_unlocked_level");
      
      setCoins(parseInt(savedCoins || "500"));
      if (savedSkins) setUnlockedSkins(JSON.parse(savedSkins));
      if (currentSkin) setSelectedSkin(currentSkin as FishSkinId);
      if (savedLevel) setUnlockedLevel(parseInt(savedLevel));
      
      setIsMuted(audio.getMuteState());
    }
  }, []);

  const handleScreenChange = (s: Screen) => {
    setScreen(s);
    audio.playClick();
  };

  const handleExitRequest = () => {
    audio.playClick();
    setIsExitDialogOpen(true);
  };

  const confirmExit = async () => {
    audio.playClick();
    console.log("Exiting application...");
    
    // Attempt to exit native app using Capacitor App plugin
    try {
      await App.exitApp();
    } catch (e) {
      // Fallback for web browser environment
      if (typeof window !== 'undefined') {
        window.location.href = "about:blank";
      }
    }
    setIsExitDialogOpen(false);
  };

  const cancelExit = () => {
    setIsExitDialogOpen(false);
    audio.playClick();
  };

  const handleLevelComplete = useCallback((stars: number, cherries: number, gameCoins: number) => {
    const reward = (stars * 100) + (cherries * 20) + gameCoins;
    
    setCoins(prev => {
      const newCoins = prev + reward;
      localStorage.setItem("tide_coins", newCoins.toString());
      return newCoins;
    });

    if (selectedLevel === unlockedLevel && unlockedLevel < 150) {
      const nextLevel = unlockedLevel + 1;
      setUnlockedLevel(nextLevel);
      localStorage.setItem("tide_unlocked_level", nextLevel.toString());
    }
  }, [selectedLevel, unlockedLevel]);

  const buySkin = (skin: FishSkinId) => {
    const price = SKIN_DATA[skin].rarity === 'Divine' ? 5000 : 2000;
    if (coins >= price && !unlockedSkins.includes(skin)) {
      const newCoins = coins - price;
      const newUnlocked = [...unlockedSkins, skin];
      setCoins(newCoins);
      setUnlockedSkins(newUnlocked);
      localStorage.setItem("tide_coins", newCoins.toString());
      localStorage.setItem("tide_skins", JSON.stringify(newUnlocked));
      audio.playChime();
    }
  };

  if (!mounted) return null;

  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden bg-[#020617] text-white select-none touch-none">
      {isPortrait ? (
        <div className="fixed inset-0 z-[999] bg-[#0c4a6e] flex flex-col items-center justify-center p-8 text-center space-y-8">
          <RotateCcw className="w-16 h-16 text-yellow-400 animate-bounce" />
          <h2 className="text-4xl font-black italic uppercase">ROTATE DEVICE</h2>
          <p className="text-sky-200">Please turn your phone sideways to play!</p>
        </div>
      ) : screen === 'PLAY' ? (
        <TideTwist
          level={{ ...GAME_MAPS[0], id: selectedLevel }}
          skin={selectedSkin}
          onHome={() => handleScreenChange('HOME')}
          onNext={() => {
            if (selectedLevel < 150) {
              const nextLvl = selectedLevel + 1;
              setSelectedLevel(nextLvl);
            } else {
              handleScreenChange('LEVELS');
            }
          }}
          onComplete={handleLevelComplete}
          onStatUpdate={() => {}}
          unlockedAchievements={[]}
          onAchievementUnlock={() => {}}
        />
      ) : (
        <main className="fixed inset-0 w-full h-full bg-[#0c4a6e] flex flex-col items-center overflow-hidden">
          {screen === 'HOME' ? (
            <HomeScreen 
              coins={coins}
              onPlay={() => handleScreenChange('LEVELS')}
              onBoutique={() => handleScreenChange('FISH')}
              onSettings={() => handleScreenChange('SETTINGS')}
              onExit={handleExitRequest}
            />
          ) : (
            <div className="w-full h-full flex flex-col bg-[#020617]">
              <div className="flex items-center justify-between px-6 py-2 z-[101] w-full border-b border-white/5 bg-black/60 backdrop-blur-md">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => handleScreenChange('HOME')} 
                    className="text-xl font-black bg-white/10 w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/20 transition-all active:scale-90 border border-white/5"
                  >
                    ‹
                  </button>
                  <h1 className="text-sm md:text-lg font-black italic uppercase tracking-tighter text-white">
                    {screen === 'LEVELS' ? 'STAGES' : screen === 'FISH' ? 'BOUTIQUE' : 'SETTINGS'}
                  </h1>
                </div>
                
                <div className="bg-yellow-400/20 text-white px-3 py-1 rounded-lg font-black shadow-lg border border-white/5 text-xs flex items-center gap-2 backdrop-blur-md">
                  <CoinIcon size="sm" /> {coins.toLocaleString()}
                </div>
              </div>

              <div className="flex-1 w-full overflow-hidden">
                {screen === 'LEVELS' && (
                  <LevelSelector 
                    biomeName="Coral Lagoon"
                    unlockedLevel={unlockedLevel}
                    onSelectLevel={(lvl) => {
                      setSelectedLevel(lvl);
                      handleScreenChange('PLAY');
                    }}
                    onBack={() => handleScreenChange('HOME')}
                  />
                )}
                {screen === 'FISH' && (
                  <FishCollection 
                    coins={coins}
                    unlockedSkins={unlockedSkins}
                    selectedSkin={selectedSkin}
                    onBuySkin={buySkin}
                    onSelectSkin={(s) => {
                      setSelectedSkin(s);
                      localStorage.setItem("tide_current_skin", s);
                    }}
                  />
                )}
                {screen === 'SETTINGS' && (
                  <div className="w-full max-w-4xl mx-auto space-y-4 pt-8 px-4 pb-20 overflow-y-auto h-full scrollbar-hide">
                    <Button className="w-full h-16 text-xl font-black rounded-3xl shadow-lg border-b-4 border-primary-foreground/20" onClick={() => {
                      audio.toggleMute();
                      setIsMuted(!isMuted);
                    }}>
                      {isMuted ? <VolumeX className="mr-3 w-6 h-6" /> : <Volume2 className="mr-3 w-6 h-6" />} 
                      SOUND: {isMuted ? 'OFF' : 'ON'}
                    </Button>

                    <Button 
                      variant="secondary"
                      className="w-full h-16 text-xl font-black rounded-3xl shadow-lg border-b-4 border-white/10 bg-white/10 hover:bg-white/20 text-white" 
                      onClick={() => {
                        setIsPrivacyOpen(true);
                        audio.playClick();
                      }}
                    >
                      <Shield className="mr-3 w-6 h-6" /> 
                      PRIVACY POLICY
                    </Button>
                    
                    <div className="bg-white/5 p-6 rounded-[2rem] border-2 border-white/5 grid grid-cols-1 md:grid-cols-3 gap-4">
                       <div className="text-center md:text-left flex flex-col items-center md:items-start">
                         <h3 className="text-xs font-black italic uppercase text-sky-300 mb-1">Total Assets</h3>
                         <div className="flex items-center gap-2 text-white text-lg font-black">
                           <CoinIcon size="sm" /> {coins.toLocaleString()}
                         </div>
                       </div>
                       <div className="text-center md:text-left flex flex-col items-center md:items-start">
                         <h3 className="text-xs font-black italic uppercase text-sky-300 mb-1">Unlocked Species</h3>
                         <p className="text-white text-lg font-black">{unlockedSkins.length} / 75</p>
                       </div>
                       <div className="text-center md:text-left flex flex-col items-center md:items-start">
                         <h3 className="text-xs font-black italic uppercase text-sky-300 mb-1">Adventure Progress</h3>
                         <p className="text-white text-lg font-black">Stage {unlockedLevel}</p>
                       </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      )}

      {/* Exit Confirmation Dialog */}
      <Dialog open={isExitDialogOpen} onOpenChange={setIsExitDialogOpen}>
        <DialogContent className="max-w-md w-[90vw] bg-[#020617] border-4 border-sky-500 rounded-[2.5rem] p-8 overflow-hidden shadow-2xl text-center">
          <DialogHeader className="space-y-4">
            <div className="mx-auto w-20 h-20 bg-sky-500/20 rounded-full flex items-center justify-center">
              <LogOut className="w-10 h-10 text-sky-400" />
            </div>
            <DialogTitle className="text-4xl font-black italic uppercase text-white tracking-tighter">
              DO YOU WANT TO EXIT?
            </DialogTitle>
            <DialogDescription className="text-sky-200 text-lg font-medium">
              Are you sure you want to quit the game?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex flex-col sm:flex-row gap-4 mt-8">
            <Button 
              className="flex-1 h-16 rounded-full font-black text-2xl bg-sky-500 hover:bg-sky-400 text-white uppercase italic border-b-4 border-sky-700 active:translate-y-1 active:border-b-0 transition-all"
              onClick={confirmExit}
            >
              EXIT
            </Button>
            <Button 
              variant="secondary"
              className="flex-1 h-16 rounded-full font-black text-2xl bg-white/10 hover:bg-white/20 text-white uppercase italic border-2 border-white/5 active:scale-95 transition-all"
              onClick={cancelExit}
            >
              CANCEL
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Privacy Policy Modal */}
      <Dialog open={isPrivacyOpen} onOpenChange={setIsPrivacyOpen}>
        <DialogContent className="max-w-2xl w-[90vw] bg-[#020617] border-2 border-sky-500 rounded-[2.5rem] p-0 overflow-hidden shadow-2xl">
          <DialogHeader className="bg-sky-500 p-6">
            <DialogTitle className="text-3xl font-black italic uppercase text-white flex items-center gap-3">
              <Shield className="w-8 h-8" /> Privacy Policy
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[60vh] p-6 text-sky-100 font-medium">
            <div className="space-y-6">
              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">1. Overview</h3>
                <p>Welcome to Tide Twist. Your privacy is important to us. This game is designed to provide a fun underwater adventure while ensuring your data remains private and secure.</p>
              </section>

              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">2. Data Collection</h3>
                <p>Tide Twist operates primarily on your local device. We do not collect personal identification information such as names, emails, or phone numbers. All game-related data (coins, unlocked levels, and fish species) is stored locally on your device's browser using LocalStorage.</p>
              </section>

              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">3. Storage & Persistence</h3>
                <p>Since all progress is saved locally, clearing your browser cache or site data will result in the permanent loss of your game progress. We do not maintain server-side backups of individual player progress.</p>
              </section>

              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">4. Third-Party Services</h3>
                <p>Our game does not currently use third-party tracking, analytics, or advertising networks that collect your personal data.</p>
              </section>

              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">5. Children's Privacy</h3>
                <p>Tide Twist is intended for a general audience. We do not knowingly collect or solicit any personal information from children under the age of 13.</p>
              </section>

              <section>
                <h3 className="text-xl font-black uppercase text-sky-400 mb-2">6. Changes to this Policy</h3>
                <p>We may update our Privacy Policy from time to time. Any changes will be reflected directly within this in-game menu.</p>
              </section>

              <div className="pt-4 border-t border-sky-500/30 text-center">
                <p className="text-sm text-sky-300/70">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </ScrollArea>
          <div className="p-4 bg-black/40 border-t border-white/5 flex justify-center">
            <Button 
              className="px-10 py-6 rounded-full font-black text-xl bg-sky-500 hover:bg-sky-400 text-white uppercase italic border-b-4 border-sky-700 active:translate-y-1 active:border-b-0 transition-all"
              onClick={() => setIsPrivacyOpen(false)}
            >
              Close Window
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
