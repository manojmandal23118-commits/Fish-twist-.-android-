
export default function VideoDetailPage() {
  return <div className="p-8">Video detail page cleared.</div>;
}
