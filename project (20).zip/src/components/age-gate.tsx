"use client"

import React, { useState, useEffect } from 'react';
import { ShieldAlert, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';

export function AgeGate({ onVerify }: { onVerify: () => void }) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const verified = localStorage.getItem('age_verified');
    if (!verified) {
      setIsVisible(true);
    }
  }, []);

  const handleAllow = () => {
    localStorage.setItem('age_verified', 'true');
    setIsVisible(false);
    onVerify();
  };

  const handleNotAllow = () => {
    // User requested: "Allow/Not Allow" button text, but proceeds either way per description ("কিছু যায় আসে না")
    // but typically a Not Allow would redirect. Here we'll follow the logic of "Proceed anyway" as hinted,
    // but maybe with a warning or just proceeding to show the content exists.
    // The user said: "এলাও করলে এলাও করুক বা নট এলাও করুক কিছু যায় আসে না কিন্তু ওইটা লেখা আসবে যে এটা এইট্টিন প্লাস ওয়েবসাইট"
    localStorage.setItem('age_verified', 'true');
    setIsVisible(false);
    onVerify();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[999] bg-background/95 backdrop-blur-md flex items-center justify-center p-4">
      <Card className="max-w-md w-full border-primary/20 bg-card/50 shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <ShieldAlert className="w-10 h-10 text-accent" />
          </div>
          <CardTitle className="text-3xl font-headline font-bold">Age Verification</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            This website contains 18+ adult content. By entering, you confirm that you are at least 18 years of age.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-2 py-6">
          <p className="text-sm font-medium text-destructive">WARNING: EXPLICIT CONTENT</p>
          <p className="text-xs text-muted-foreground px-4">
            If you are under 18 or easily offended, please do not proceed.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          <Button 
            className="w-full h-12 text-lg font-semibold bg-primary hover:bg-primary/80" 
            onClick={handleAllow}
          >
            Allow
          </Button>
          <Button 
            variant="outline" 
            className="w-full h-12 text-lg font-semibold border-muted hover:bg-muted/20" 
            onClick={handleNotAllow}
          >
            Not Allow
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}