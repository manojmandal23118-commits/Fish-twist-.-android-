"use client"

import React, { useState } from 'react';
import { Lock, Eye, EyeOff, ShieldCheck, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

interface PasswordGateProps {
  correctPassword?: string;
  onSuccess: () => void;
}

export function PasswordGate({ correctPassword, onSuccess }: PasswordGateProps) {
  const [input, setInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input === correctPassword) {
      onSuccess();
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="aspect-video w-full bg-secondary/20 flex flex-col items-center justify-center p-6 rounded-xl border-2 border-dashed border-primary/30">
      <Card className="max-w-md w-full border-primary/20 bg-background/80 backdrop-blur-md shadow-2xl">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
            <Lock className="w-6 h-6 text-accent" />
          </div>
          <CardTitle className="text-xl font-headline font-bold">Locked Content</CardTitle>
          <CardDescription>
            Please enter the correct password to unlock and stream this video.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-2">
              <div className="relative">
                <Input 
                  type={showPassword ? "text" : "password"} 
                  className={`h-11 bg-secondary/30 border-none pr-10 focus-visible:ring-1 focus-visible:ring-accent ${error ? 'ring-2 ring-destructive' : ''}`}
                  placeholder="Password..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  autoFocus
                />
                <button 
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {error && <p className="text-[10px] text-destructive font-medium text-center">Incorrect password. Please try again.</p>}
            </div>
            <Button type="submit" className="w-full h-11 bg-primary hover:bg-primary/80">
              <ShieldCheck className="w-4 h-4 mr-2" />
              Unlock Video
            </Button>
          </form>

          {correctPassword && (
            <div className="mt-4 p-3 rounded-lg bg-accent/10 border border-accent/20 flex items-start gap-3">
              <Info className="w-4 h-4 text-accent mt-0.5 shrink-0" />
              <div className="space-y-1">
                <p className="text-xs font-semibold text-accent uppercase tracking-wider">Password Hint</p>
                <p className="text-sm font-headline text-foreground">
                  The password for this video is: <span className="font-bold underline">{correctPassword}</span>
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}