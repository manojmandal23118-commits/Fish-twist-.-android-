
'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from '@/lib/game/engine';
import { LevelData } from '@/lib/game/types';
import { Button } from '@/components/ui/button';
import { Home, Pause, Play, Star, RotateCcw, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Joystick } from '@/components/game/ui/joystick';

interface TideTwistProps {
  level: LevelData;
  skin: string;
  onHome: () => void;
  onNext: () => void;
  onComplete: (stars: number, cherries: number, gameCoins: number) => void;
  onStatUpdate: (type: 'shield' | 'jump') => void;
  unlockedAchievements: string[];
  onAchievementUnlock: (id: string) => void;
}

export default function TideTwist({ level, skin, onHome, onNext, onComplete }: TideTwistProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const lastTimeRef = useRef<number>(0);
  
  const [isPaused, setIsPaused] = useState(false);
  const [victory, setVictory] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [foodCount, setFoodCount] = useState(0);
  const [coinsInGame, setCoinsInGame] = useState(0);
  const [progress, setProgress] = useState(0);

  const initGame = useCallback(() => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    
    const engine = new GameEngine(w, h, {
      onWin: () => setVictory(true),
      onGameOver: () => setGameOver(true)
    });
    
    engine.player.skin = skin;
    engine.loadMap(level.id - 1);
    engine.state = 'PLAYING';
    engineRef.current = engine;
    
    setVictory(false);
    setGameOver(false);
    setProgress(0);
    setFoodCount(0);
    setCoinsInGame(0);
    lastTimeRef.current = performance.now();
  }, [skin, level]);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const animate = useCallback((currentTime: number) => {
    const engine = engineRef.current;
    const canvas = canvasRef.current;
    
    const dt = Math.min(0.05, (currentTime - lastTimeRef.current) / 1000);
    lastTimeRef.current = currentTime;
    
    if (engine && canvas && !isPaused) {
      engine.update(dt);
      
      setFoodCount(engine.cherriesCollected);
      setCoinsInGame(engine.score);
      setProgress((engine.player.x / engine.worldWidth) * 100);
      
      const ctx = canvas.getContext('2d', { alpha: false });
      if (ctx) {
        const dpr = window.devicePixelRatio || 1;
        if (canvas.width !== window.innerWidth * dpr || canvas.height !== window.innerHeight * dpr) {
          canvas.width = window.innerWidth * dpr;
          canvas.height = window.innerHeight * dpr;
          engine.width = window.innerWidth;
          engine.height = window.innerHeight;
        }

        ctx.save();
        ctx.scale(dpr, dpr);
        engine.render(ctx);
        ctx.restore();
      }
    }
    requestAnimationFrame(animate);
  }, [isPaused]);

  useEffect(() => {
    const id = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(id);
  }, [animate]);

  const handleNextLevel = () => {
    onComplete(3, foodCount, coinsInGame);
    onNext();
  };

  const handleCanvasPointer = (e: React.PointerEvent) => {
    const engine = engineRef.current;
    const canvas = canvasRef.current;
    if (!engine || !canvas || isPaused || victory || gameOver) return;

    const rect = canvas.getBoundingClientRect();
    // Calculate world coordinates based on camera position
    const x = (e.clientX - rect.left) + engine.camera.x;
    const y = (e.clientY - rect.top);
    
    // Set target for tap-to-move logic
    engine.setTarget(x, y);
  };

  const handleCanvasPointerUp = () => {
    // Optionally stop moving on pointer up if dragging, 
    // but for tap-to-move we often want it to continue to the destination.
    // engineRef.current?.clearTarget(); 
  };

  return (
    <div className="fixed inset-0 w-full h-full overflow-hidden bg-[#0c4a6e] z-10 will-change-transform transform-gpu">
      <canvas 
        ref={canvasRef} 
        className="w-full h-full block cursor-crosshair touch-none" 
        onPointerDown={handleCanvasPointer}
        onPointerMove={handleCanvasPointer}
        onPointerUp={handleCanvasPointerUp}
        onPointerLeave={handleCanvasPointerUp}
      />
      
      {/* Top UI Overlay - Semi-Transparent HUD */}
      <div className="absolute top-0 left-0 w-full p-4 flex flex-col items-center gap-2 z-[70] pointer-events-none">
        <div className="w-full max-w-2xl bg-black/10 backdrop-blur-[2px] p-3 rounded-2xl flex items-center gap-4 pointer-events-auto border border-white/5 transition-colors hover:bg-black/20">
          <Button variant="ghost" size="icon" onClick={onHome} className="text-white hover:bg-white/20 rounded-xl">
            <Home className="w-6 h-6" />
          </Button>
          <div className="flex-1 space-y-1">
            <div className="flex justify-between text-[10px] font-black text-white uppercase tracking-widest opacity-90 drop-shadow-md">
              <span>START</span>
              <span>{Math.round(progress)}%</span>
              <span>FINISH</span>
            </div>
            <Progress value={progress} className="h-2 bg-white/10" />
          </div>
          <div className="flex gap-2">
            <div className="bg-red-500/80 text-white px-3 py-1 rounded-xl font-black text-xs shadow-lg border border-red-400/30 backdrop-blur-sm">
              🍒 {foodCount}
            </div>
            <div className="bg-yellow-400/80 text-black px-3 py-1 rounded-xl font-black text-xs shadow-lg border border-yellow-600/30 backdrop-blur-sm">
              🟡 {coinsInGame}
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons Overlay */}
      <div className="absolute top-24 left-4 flex flex-col gap-3 z-[70]">
        <Button variant="secondary" size="icon" onClick={initGame} className="rounded-full bg-white/10 text-white backdrop-blur-md border-2 border-white/20 hover:bg-white/20 transition-all active:scale-90">
          <RotateCcw />
        </Button>
        <Button variant="secondary" size="icon" onClick={() => setIsPaused(!isPaused)} className="rounded-full bg-white/10 text-white backdrop-blur-md border-2 border-white/20 hover:bg-white/20 transition-all active:scale-90">
          {isPaused ? <Play /> : <Pause />}
        </Button>
      </div>

      {/* Virtual Joystick - Right Side */}
      {!victory && !gameOver && !isPaused && (
        <Joystick 
          onMove={(input) => {
            if (engineRef.current) {
              engineRef.current.joystickInput = input;
            }
          }}
          onEnd={() => {
            if (engineRef.current) {
              engineRef.current.joystickInput = null;
            }
          }}
        />
      )}

      {/* Full Screen Modals */}
      {isPaused && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[80] animate-in fade-in duration-300">
          <div className="bg-sky-900/90 p-12 rounded-[3.5rem] text-center border-8 border-sky-400 shadow-2xl scale-110">
            <h2 className="text-7xl font-black text-white italic mb-10 uppercase tracking-tighter">PAUSED</h2>
            <Button size="lg" className="h-24 w-72 rounded-full text-4xl font-black bg-sky-400 text-white hover:bg-sky-300 shadow-xl shadow-sky-400/20" onClick={() => setIsPaused(false)}>RESUME</Button>
          </div>
        </div>
      )}

      {victory && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-[90] animate-in zoom-in duration-500">
          <div className="bg-white p-12 rounded-[4rem] text-center border-[14px] border-sky-500 shadow-2xl max-w-lg w-full">
            <h2 className="text-6xl font-black text-sky-900 mb-6 italic uppercase tracking-tighter">CLEAR!</h2>
            <div className="flex justify-center gap-6 mb-8">
              {[1, 2, 3].map(i => (
                <Star key={i} className="w-20 h-20 fill-yellow-400 text-yellow-500 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
              ))}
            </div>
            <div className="mb-8 bg-sky-100/50 p-6 rounded-[2.5rem] border-2 border-sky-200">
              <p className="text-sky-900 font-black text-xl uppercase italic mb-2">Earnings:</p>
              <div className="flex justify-center gap-10 mt-2">
                <div className="text-3xl font-black text-yellow-600">🟡 {coinsInGame}</div>
                <div className="text-3xl font-black text-red-500">🍒 {foodCount}</div>
              </div>
            </div>
            <div className="space-y-4">
              <Button size="lg" className="w-full h-24 rounded-full text-4xl font-black bg-sky-500 text-white shadow-xl hover:bg-sky-400 uppercase transition-all active:translate-y-2 border-b-8 border-sky-700" onClick={handleNextLevel}>
                NEXT LEVEL →
              </Button>
              <Button variant="outline" size="lg" className="w-full h-20 rounded-full text-2xl font-black border-4 border-sky-900 text-sky-900 hover:bg-sky-50 transition-all active:translate-y-1" onClick={initGame}>
                REPLAY
              </Button>
            </div>
          </div>
        </div>
      )}

      {gameOver && (
        <div className="absolute inset-0 bg-red-950/90 backdrop-blur-md flex items-center justify-center p-4 z-[95] animate-in fade-in zoom-in duration-500">
          <div className="bg-slate-900 p-12 rounded-[4rem] text-center border-[14px] border-red-600 shadow-2xl max-w-lg w-full">
            <div className="mb-6 flex justify-center">
              <AlertTriangle className="w-24 h-24 text-red-500 animate-pulse" />
            </div>
            <h2 className="text-6xl font-black text-white mb-6 italic uppercase tracking-tighter">EXPLOSION!</h2>
            <p className="text-red-400 font-bold mb-8 uppercase tracking-widest">You hit a grenade!</p>
            <div className="space-y-4">
              <Button size="lg" className="w-full h-24 rounded-full text-4xl font-black bg-red-600 text-white shadow-xl hover:bg-red-500 uppercase transition-all active:translate-y-2 border-b-8 border-red-800" onClick={initGame}>
                TRY AGAIN
              </Button>
              <Button variant="outline" size="lg" className="w-full h-20 rounded-full text-2xl font-black border-4 border-white text-white hover:bg-white/10 transition-all active:translate-y-1" onClick={onHome}>
                QUIT
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
