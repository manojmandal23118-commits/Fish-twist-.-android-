'use client';

import React, { useRef, useEffect } from 'react';
import { INITIAL_SKINS } from '@/lib/game/types';
import { drawPlayer } from '@/lib/game/drawing-utils';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { CoinIcon } from '@/components/game/ui/coin-icon';

const FishPreview = ({ skinId }: { skinId: string }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    
    let animationId: number;
    const skin = INITIAL_SKINS.find(s => s.id === skinId);
    // Adapt scale based on aspect ratio to fit large/wide creatures
    const aspect = skin?.aspectMultiplier || 1.2;
    const scaleFactor = 16 / Math.max(aspect, 1.3);

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      drawPlayer(ctx, { 
        x: canvas.width / 2, 
        y: canvas.height / 2, 
        radius: scaleFactor, 
        skin: skinId, 
        vx: 1 
      });
      animationId = requestAnimationFrame(render);
    };
    render();
    return () => cancelAnimationFrame(animationId);
  }, [skinId]);

  return <canvas ref={canvasRef} width={80} height={80} className="w-16 h-16 drop-shadow-xl" />;
};

interface FishCollectionProps {
  coins: number;
  unlockedSkins: string[];
  selectedSkin: string;
  onBuySkin: (skinId: string) => void;
  onSelectSkin: (skinId: string) => void;
}

export function FishCollection({ coins, unlockedSkins, selectedSkin, onBuySkin, onSelectSkin }: FishCollectionProps) {
  return (
    <div className="w-full h-full bg-[#0c4a6e]/20 backdrop-blur-md overflow-hidden boutique-container">
      <ScrollArea className="h-full w-full">
        <div className="p-4 pb-20">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {INITIAL_SKINS.map((skin) => {
              const isUnlocked = unlockedSkins.includes(skin.id);
              const isSelected = selectedSkin === skin.id;
              const canAfford = coins >= skin.price;

              return (
                <div 
                  key={skin.id}
                  onClick={() => isUnlocked && onSelectSkin(skin.id)}
                  className={cn(
                    "group relative bg-white/5 border-2 rounded-[1.5rem] p-4 flex flex-col items-center gap-2 transition-all cursor-pointer min-h-[160px]",
                    isSelected 
                      ? "border-yellow-400 bg-white/10 scale-102 shadow-xl shadow-yellow-400/10" 
                      : "border-white/5 hover:border-white/20 hover:scale-101"
                  )}
                >
                  <div className="absolute top-2 left-2 z-10">
                    <Badge className={cn(
                      "font-black text-[8px] py-0 px-2 shadow-sm uppercase",
                      skin.rarity === 'Divine' ? "bg-purple-600" : 
                      skin.rarity === 'Legendary' ? "bg-orange-500" : 
                      skin.rarity === 'Epic' ? "bg-pink-600" : 
                      skin.rarity === 'Rare' ? "bg-sky-600" : "bg-gray-600"
                    )}>
                      {skin.rarity}
                    </Badge>
                  </div>

                  <div className="relative mt-1">
                    <FishPreview skinId={skin.id} />
                  </div>
                  
                  <div className="text-center w-full px-1">
                    <h3 className="font-black text-white text-[9px] leading-tight uppercase tracking-tighter truncate">
                      {skin.name}
                    </h3>
                  </div>

                  <div className="w-full mt-auto">
                    {isSelected ? (
                      <div className="w-full py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-[8px] font-black text-center border border-cyan-400/20 uppercase">
                        EQUIPPED
                      </div>
                    ) : isUnlocked ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectSkin(skin.id);
                        }}
                        className="w-full py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[8px] font-black border-b-2 border-white/5 transition-all active:translate-y-0.5 uppercase"
                      >
                        SELECT
                      </button>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onBuySkin(skin.id);
                        }}
                        disabled={!canAfford}
                        className={cn(
                          "w-full py-1.5 rounded-lg font-black text-[8px] shadow-md border-b-2 transition-all active:translate-y-0.5 uppercase flex items-center justify-center gap-1.5",
                          canAfford 
                            ? "bg-yellow-400 border-yellow-700 text-black hover:bg-yellow-300" 
                            : "bg-slate-800 border-slate-900 text-slate-500 cursor-not-allowed opacity-50"
                        )}
                      >
                        <CoinIcon size="sm" className={cn(!canAfford && "opacity-50")} />
                        {skin.price.toLocaleString()}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
