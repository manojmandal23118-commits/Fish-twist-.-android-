'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface CoinIconProps {
  className?: string;
  size?: 'sm' | 'lg' | 'default';
}

export function CoinIcon({ className, size = 'sm' }: CoinIconProps) {
  return (
    <div className={cn(
      "game-coin-custom active:scale-95 transition-all duration-200",
      size === 'sm' && "game-coin-sm",
      size === 'lg' && "game-coin-lg",
      className
    )}>
      {/* Glossy Reflection */}
      <div className="coin-glossy-shine" />

      {/* Engraved Leaping Fish Graphic */}
      <svg className="coin-fish-engraved" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path 
          d="M20 70 C 10 50, 30 20, 55 23 C 80 27, 80 60, 70 70 C 60 80, 40 70, 25 70 Z" 
          stroke="#5d4037" 
          strokeWidth="3" 
          strokeLinecap="round" 
          strokeLinejoin="round"
          fill="rgba(93, 64, 55, 0.1)"
        />
        <path 
          d="M40 27 C 43 10, 55 10, 60 25 L 40 27" 
          stroke="#5d4037" 
          strokeWidth="2.5" 
          fill="rgba(93, 64, 55, 0.2)"
        />
        <path 
          d="M70 70 C 83 77, 87 70, 85 60 C 80 63, 75 67, 70 70 Z" 
          stroke="#5d4037" 
          strokeWidth="2.5" 
          fill="rgba(93, 64, 55, 0.2)"
        />
        <path 
          d="M70 70 C 75 85, 65 90, 60 85 C 63 80, 67 75, 70 70 Z" 
          stroke="#5d4037" 
          strokeWidth="2.5" 
          fill="rgba(93, 64, 55, 0.2)"
        />
        <circle cx="30" cy="55" r="2.5" fill="#5d4037" />
        <path d="M37 60 Q 40 58 43 62" stroke="#5d4037" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M43 55 Q 46 53 49 57" stroke="#5d4037" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
    </div>
  );
}
