'use client';

import React from 'react';
import { GAME_MAPS } from '@/lib/game/levels';
import { ScrollArea } from '@/components/ui/scroll-area';

interface LevelSelectProps {
  onSelectLevel: (levelIndex: number) => void;
  onBack: () => void;
}

export const LevelSelect: React.FC<LevelSelectProps> = ({ onSelectLevel, onBack }) => {
  return (
    <div className="w-full flex flex-col h-full overflow-hidden bg-slate-950/20">
      <ScrollArea className="flex-1 w-full h-full">
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-24">
          {GAME_MAPS.map((map, idx) => (
            <div
              key={map.id}
              onClick={() => onSelectLevel(idx)}
              className="group relative overflow-hidden rounded-[1.5rem] p-5 border-2 border-white/5 bg-slate-900/60 hover:border-sky-400 hover:scale-[1.02] transition-all duration-300 cursor-pointer flex flex-col justify-between shadow-xl min-h-[200px]"
              style={{
                background: `linear-gradient(135deg, ${map.waterColors[0]}44, ${map.waterColors[2]}aa)`
              }}
            >
              <div className="z-10 relative pointer-events-none">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[8px] font-black px-2 py-0.5 rounded-full bg-white/10 text-white border border-white/5 uppercase tracking-widest">
                    #{map.id} {map.theme.replace('_', ' ')}
                  </span>
                </div>
                <h3 className="text-xl font-black text-white group-hover:text-sky-300 transition-colors mb-1 italic uppercase tracking-tighter">
                  {map.name}
                </h3>
                <p className="text-[11px] text-sky-100/70 font-medium line-clamp-2 italic leading-tight">
                  {map.description}
                </p>
              </div>

              <div className="w-full mt-4 py-2 bg-sky-500 group-hover:bg-sky-400 text-white font-black text-center text-[10px] rounded-xl shadow-lg transition-all border-b-2 border-sky-700 active:border-b-0 uppercase italic tracking-widest pointer-events-none">
                EXPLORE REALM →
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};
