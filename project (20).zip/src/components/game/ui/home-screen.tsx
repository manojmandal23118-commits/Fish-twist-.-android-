
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Play, Fish, Settings, LogOut } from 'lucide-react';
import { CoinIcon } from '@/components/game/ui/coin-icon';

interface HomeScreenProps {
  coins: number;
  onPlay: () => void;
  onBoutique: () => void;
  onSettings: () => void;
  onExit: () => void;
}

export function HomeScreen({ coins, onPlay, onBoutique, onSettings, onExit }: HomeScreenProps) {
  return (
    <div className="home-menu-container animate-in fade-in duration-700 scrollbar-hide flex flex-col items-center justify-center min-h-screen w-full relative">
      <div className="fixed top-4 right-4 z-[60]">
        <div className="bg-yellow-400/20 text-white font-black text-xl px-4 py-1.5 rounded-xl flex items-center gap-3 shadow-2xl border border-white/10 backdrop-blur-md">
          <CoinIcon size="lg" />
          <span>{coins.toLocaleString()}</span>
        </div>
      </div>

      <div className="text-center space-y-2 select-none mb-8 mt-2">
        <h1 className="text-5xl md:text-8xl font-black italic tracking-tighter text-white drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)] animate-bounce-slow uppercase">
          TIDE <span className="text-yellow-300">TWIST</span>
        </h1>
        <p className="text-sky-300 font-black tracking-[0.4em] uppercase text-[10px] md:text-sm opacity-80">
          AN UNDERWATER ADVENTURE
        </p>
      </div>

      <div className="flex flex-col gap-4 items-center w-full max-w-sm pb-10">
        <div className="w-full">
          <Button 
            size="lg" 
            className="h-20 w-full text-3xl font-black rounded-[2rem] shadow-2xl active:translate-y-1 transition-all bg-sky-500 hover:bg-sky-400 border-b-6 border-sky-800 text-white uppercase italic" 
            onClick={onPlay}
          >
            <Play className="mr-3 w-8 h-8 fill-current" /> START GAME
          </Button>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full">
          <Button 
            variant="secondary" 
            size="lg" 
            className="w-full sm:flex-1 h-16 rounded-[1.5rem] text-lg font-black border-2 border-white/5 active:scale-95 bg-white/10 hover:bg-white/20 text-white shadow-lg" 
            onClick={onBoutique}
          >
            <Fish className="mr-2 w-5 h-5" /> BOUTIQUE
          </Button>
          <Button 
            variant="secondary" 
            size="lg" 
            className="w-full sm:flex-1 h-16 rounded-[1.5rem] text-lg font-black border-2 border-white/5 active:scale-95 bg-white/10 hover:bg-white/20 text-white shadow-lg" 
            onClick={onSettings}
          >
            <Settings className="mr-2 w-5 h-5" /> SETTINGS
          </Button>
        </div>

        <div className="w-full mt-2">
          <Button 
            variant="ghost"
            className="w-full h-12 rounded-[1rem] text-sm font-black text-sky-400 hover:text-white hover:bg-red-500/20 uppercase tracking-widest transition-all" 
            onClick={onExit}
          >
            <LogOut className="mr-2 w-4 h-4" /> QUIT GAME
          </Button>
        </div>
      </div>
    </div>
  );
}
