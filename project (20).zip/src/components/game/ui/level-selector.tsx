'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Lock } from 'lucide-react';

interface LevelSelectorProps {
  biomeName: string;
  unlockedLevel: number;
  onSelectLevel: (level: number) => void;
  onBack: () => void;
}

export const LevelSelector: React.FC<LevelSelectorProps> = ({
  biomeName,
  unlockedLevel,
  onSelectLevel,
  onBack,
}) => {
  // Increased total levels to 150 to accommodate all grenade progression milestones
  const levels = Array.from({ length: 150 }, (_, i) => i + 1);

  return (
    <div className="w-full h-full flex flex-col items-center bg-[#020617] animate-in fade-in duration-500">
      {/* Header - Slim & Compact */}
      <div className="w-full flex items-center justify-between px-6 py-2 bg-sky-900/40 border-b border-sky-400/20 backdrop-blur-md">
        <div className="flex flex-col">
          <h2 className="text-xl font-black uppercase italic text-sky-400 tracking-tighter leading-none">
            SELECT STAGE
          </h2>
          <p className="text-[9px] font-bold text-slate-400 tracking-widest uppercase opacity-70">
            {biomeName} • 01-150
          </p>
        </div>
        <button
          onClick={onBack}
          className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-black text-xs border-b-4 border-black/40 transition-all active:translate-y-1 active:border-b-0 uppercase tracking-widest"
        >
          ← EXIT
        </button>
      </div>

      {/* Main Grid - Full Screen Space */}
      <div className="flex-1 w-full p-4 overflow-hidden">
        <ScrollArea className="h-full w-full">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 pb-20">
            {levels.map((lvl) => {
              const isLocked = lvl > unlockedLevel;
              
              return (
                <button
                  key={lvl}
                  disabled={isLocked}
                  onClick={() => onSelectLevel(lvl)}
                  className={cn(
                    "group relative aspect-square w-full rounded-[2rem] font-black text-3xl shadow-2xl transition-all flex flex-col items-center justify-center overflow-hidden border-2",
                    isLocked 
                      ? "bg-slate-900/50 border-white/5 opacity-40 cursor-not-allowed" 
                      : "bg-gradient-to-br from-sky-500 to-sky-700 border-sky-400 hover:scale-105 active:scale-95 border-b-8 border-sky-900 active:border-b-0 cursor-pointer"
                  )}
                >
                  <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  {isLocked ? (
                    <div className="flex flex-col items-center gap-2">
                      <Lock className="w-8 h-8 text-slate-500" />
                      <span className="text-[10px] uppercase text-slate-500 font-bold">LOCKED</span>
                    </div>
                  ) : (
                    <>
                      <span className="italic relative z-10 text-white drop-shadow-lg">{lvl}</span>
                      <span className="text-[8px] uppercase opacity-60 relative z-10 font-black tracking-widest text-white">LEVEL {lvl > 30 ? '🔥' : ''}</span>
                    </>
                  )}
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
};
