
'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';

interface JoystickProps {
  onMove: (input: { x: number; y: number }) => void;
  onEnd: () => void;
}

export function Joystick({ onMove, onEnd }: JoystickProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const baseRef = useRef<HTMLDivElement>(null);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    handlePointerMove(e);
  };

  const handlePointerMove = useCallback((e: MouseEvent | React.PointerEvent) => {
    if (!isDragging || !baseRef.current) return;

    const rect = baseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    let dx = e.clientX - centerX;
    let dy = e.clientY - centerY;
    
    const distance = Math.hypot(dx, dy);
    const maxRadius = rect.width / 2;
    
    // Normalize and limit movement
    if (distance > maxRadius) {
      dx = (dx / distance) * maxRadius;
      dy = (dy / distance) * maxRadius;
    }
    
    setKnobPos({ x: dx, y: dy });
    
    // Normalize values to -1 to 1 range with high precision for the engine
    onMove({ x: dx / maxRadius, y: dy / maxRadius });
  }, [isDragging, onMove]);

  const handlePointerUp = useCallback(() => {
    setIsDragging(false);
    setKnobPos({ x: 0, y: 0 });
    onEnd();
  }, [onEnd]);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('pointermove', handlePointerMove, { passive: true });
      window.addEventListener('pointerup', handlePointerUp, { passive: true });
    } else {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    }
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [isDragging, handlePointerMove, handlePointerUp]);

  return (
    <div 
      className="fixed bottom-10 right-10 z-[100] touch-none select-none"
      onPointerDown={handlePointerDown}
    >
      <div 
        ref={baseRef}
        className="relative w-32 h-32 rounded-full bg-white/10 backdrop-blur-md border-2 border-white/20 shadow-2xl flex items-center justify-center overflow-hidden"
      >
        {/* Subtle decorative ring */}
        <div className="absolute inset-2 rounded-full border border-white/5 pointer-events-none" />
        
        {/* Joystick Knob */}
        <div 
          className="w-14 h-14 rounded-full bg-sky-400 border-2 border-white/40 shadow-xl transition-transform duration-75 active:scale-95 flex items-center justify-center"
          style={{ 
            transform: `translate3d(${knobPos.x}px, ${knobPos.y}px, 0)`,
            willChange: 'transform'
          }}
        >
          {/* Knob Inner Detail */}
          <div className="w-8 h-8 rounded-full bg-white/20 border border-white/10" />
        </div>
      </div>
    </div>
  );
}
