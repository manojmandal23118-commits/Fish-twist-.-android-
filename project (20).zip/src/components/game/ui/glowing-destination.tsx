'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface GlowingDestinationProps {
  level: number;
  className?: string;
}

export default function GlowingDestination({ level, className }: GlowingDestinationProps) {
  // Map Level to specific hue-rotate values or specific pearl-level classes
  // Level 1: Cyan, Level 2: Emerald, Level 3: Amethyst, Level 4: Gold
  const levelClass = `pearl-level-${((level - 1) % 4) + 1}`;
  
  return (
    <div className={cn("destination-container scale-125", className)}>
      {/* Background massive light burst aura */}
      <div className="pearl-light-burst" />

      {/* Oyster shell representation for UI */}
      <div className="destination-shell-bottom" />
      <div className="destination-shell-top" />

      {/* The Magical Pearl Core */}
      <div className={cn("destination-pearl", levelClass)} />
    </div>
  );
}
