"use client"

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Lock, Clock, Tag } from 'lucide-react';
import type { Video } from '@/lib/types';
import { Badge } from '@/components/ui/badge';

export function VideoCard({ video }: { video: Video }) {
  return (
    <Link href={`/video/${video.id}`} className="group block">
      <div className="relative aspect-video rounded-xl overflow-hidden bg-muted mb-3 border border-border group-hover:border-accent/50 transition-all shadow-md">
        <Image 
          src={video.thumbnailUrl} 
          alt={video.title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          data-ai-hint="video thumbnail"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
        
        {video.password && (
          <div className="absolute top-2 right-2">
            <Badge variant="secondary" className="bg-black/60 backdrop-blur-md text-white border-none py-1 px-2 flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span className="text-[10px]">LOCKED</span>
            </Badge>
          </div>
        )}

        <div className="absolute bottom-2 right-2">
          <Badge className="bg-primary/80 backdrop-blur-md border-none text-[10px] py-0.5 px-1.5">
            18+
          </Badge>
        </div>
      </div>
      
      <div className="space-y-1">
        <h3 className="font-headline font-semibold text-foreground line-clamp-2 group-hover:text-accent transition-colors">
          {video.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {video.uploadDate}
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Tag className="w-3 h-3" />
            {video.categories[0]}
          </span>
        </div>
      </div>
    </Link>
  );
}