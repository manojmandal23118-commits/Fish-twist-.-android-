import { LevelData, BiomeType } from './types';

/**
 * @fileOverview Level templates and progressive distance system.
 * Distances are calculated dynamically in the engine based on these templates.
 */

export interface LevelDefinition {
  levelNumber: number;
  targetDistance: number;
  obstacleDensity: number;
  currentStrength: number;
}

export class LevelSystem {
  /**
   * Helper to calculate level difficulty and distance parameters.
   * Progression: 100m + 20m per level.
   */
  public static getLevelDefinition(levelNum: number): LevelDefinition {
    return {
      levelNumber: levelNum,
      targetDistance: 100 + (levelNum - 1) * 20,
      obstacleDensity: 1.0 + (levelNum * 0.1),
      currentStrength: 1.0 + (levelNum * 0.05)
    };
  }
}

export const GAME_MAPS: LevelData[] = [
  {
    id: 1,
    name: 'Coral Lagoon',
    theme: 'coral_lagoon',
    worldWidth: 4000, 
    targetCherries: 5,
    description: 'Bright sunny reefs with colorful creatures.',
    waterColors: ['#0077B6', '#0096C7', '#00B4D8'],
    sandColor: '#E9C46A',
    sunrayColor: '#90E0EF',
    plantType: 1,
    ambientFishColor: '#FF7A00',
    ambientCreatures: [],
    currents: [{ startX: 600, startY: 300, endX: 1500, endY: 300, forceX: 1.5, forceY: 0 }],
    collectibles: [],
    obstacles: [],
    fishSchools: []
  },
  {
    id: 2,
    name: 'Midnight Abyss',
    theme: 'deep_sea',
    worldWidth: 6000,
    targetCherries: 6,
    description: 'Pitch black depths with glowing hazards.',
    waterColors: ['#03071E', '#080808', '#000000'],
    sandColor: '#2B2D42',
    sunrayColor: '#7209B7',
    plantType: 2,
    ambientFishColor: '#00F5D4',
    ambientCreatures: [],
    currents: [],
    collectibles: [],
    obstacles: [],
    fishSchools: []
  },
  {
    id: 3,
    name: 'Volcanic Vent',
    theme: 'volcanic_reef',
    worldWidth: 8000,
    targetCherries: 8,
    description: 'Boiling magma streams and volcanic rock barriers.',
    waterColors: ['#6A040F', '#370617', '#100003'],
    sandColor: '#9D0208',
    sunrayColor: '#FF5400',
    plantType: 3,
    ambientFishColor: '#FFBA08',
    ambientCreatures: [],
    currents: [],
    collectibles: [],
    obstacles: [],
    fishSchools: []
  }
];
