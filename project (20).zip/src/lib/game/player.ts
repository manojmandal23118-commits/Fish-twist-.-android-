'use client';

import { Vector, FishSkinId, MAP_WIDTH, MAP_HEIGHT } from './types';

export class Player {
  x: number;
  y: number;
  radius: number = 22;
  
  vx: number = 0;
  vy: number = 0;
  accel: number = 0.25;
  friction: number = 0.95;
  maxSpeed: number = 4.5;
  
  targetX: number;
  targetY: number;
  angle: number = 0;
  skin: FishSkinId;
  
  baseScale: number = 0.8;
  currentScale: number = 0.8;
  targetScale: number = 0.8;

  facingLeft: boolean = false;
  magnetTimer: number = 0;
  hasShield: boolean = false;
  dizzyTimer: number = 0;

  constructor(x: number, y: number, skin: FishSkinId = 'fish_1') {
    this.x = x;
    this.y = y;
    this.targetX = x;
    this.targetY = y;
    this.skin = skin;
  }

  setTarget(x: number, y: number) {
    if (this.dizzyTimer > 0) return;
    this.targetX = x;
    this.targetY = y;
  }

  update(current: { getVector: () => Vector, strength: number }) {
    if (this.dizzyTimer > 0) {
      this.dizzyTimer--;
      this.vx *= 0.85;
      this.vy *= 0.85;
    } else {
      const dx = this.targetX - this.x;
      const dy = this.targetY - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist > 15) {
        this.vx += (dx / dist) * this.accel;
        this.vy += (dy / dist) * this.accel;
      }
    }

    const currentSpeed = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
    if (currentSpeed > this.maxSpeed) {
      this.vx = (this.vx / currentSpeed) * this.maxSpeed;
      this.vy = (this.vy / currentSpeed) * this.maxSpeed;
    }

    this.vx *= this.friction;
    this.vy *= this.friction;

    this.x += this.vx;
    this.y += this.vy;

    const currentForce = current.getVector();
    this.x += currentForce.x * current.strength;
    this.y += currentForce.y * current.strength;

    if (Math.abs(this.currentScale - this.targetScale) > 0.001) {
      this.currentScale += (this.targetScale - this.currentScale) * 0.05;
    }

    if (this.magnetTimer > 0) this.magnetTimer--;

    // World boundaries
    const bound = this.radius * this.currentScale;
    if (this.x < bound) { this.x = bound; this.vx *= -0.5; }
    if (this.x > MAP_WIDTH - bound) { this.x = MAP_WIDTH - bound; this.vx *= -0.5; }
    if (this.y < bound) { this.y = bound; this.vy *= -0.5; }
    if (this.y > MAP_HEIGHT - 60 - bound) { this.y = MAP_HEIGHT - 60 - bound; this.vy *= -0.5; }
  }

  grow(inc: number) {
    this.targetScale = Math.min(this.targetScale + inc, 1.8);
  }

  reset(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.targetX = x;
    this.targetY = y;
    this.currentScale = this.baseScale;
    this.targetScale = this.baseScale;
    this.hasShield = false;
    this.magnetTimer = 0;
    this.dizzyTimer = 0;
  }
}