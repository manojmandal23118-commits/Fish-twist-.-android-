'use client';

class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private isMuted: boolean = false;
  private musicInterval: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const savedMute = localStorage.getItem('tide_twist_muted');
      this.isMuted = savedMute === 'true';
    }
  }

  private init() {
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();
    
    this.masterGain.connect(this.ctx.destination);
    this.musicGain.connect(this.masterGain);
    
    this.masterGain.gain.value = this.isMuted ? 0 : 1;
    this.musicGain.gain.value = 0.1; // Very soft background music

    this.startMusic();
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : 1, this.ctx!.currentTime, 0.1);
    }
    localStorage.setItem('tide_twist_muted', String(this.isMuted));
    return this.isMuted;
  }

  getMuteState() {
    return this.isMuted;
  }

  private playTone(freq: number, type: OscillatorType, duration: number, volume: number = 0.5, slideTo?: number) {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    if (slideTo) {
      osc.frequency.exponentialRampToValueAtTime(slideTo, this.ctx.currentTime + duration);
    }

    g.gain.setValueAtTime(volume, this.ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    osc.connect(g);
    g.connect(this.masterGain);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  // Soft bubble pop sound
  playPop() {
    this.playTone(800, 'sine', 0.1, 0.2, 1200);
  }

  // Gentle cute munch/bite
  playBite() {
    this.playTone(400, 'triangle', 0.08, 0.25, 200);
  }

  // Soft water bounce
  playBounce() {
    this.playTone(200, 'sine', 0.2, 0.3, 300);
  }

  // Magical gentle chime
  playChime() {
    const now = this.ctx?.currentTime || 0;
    const notes = [659.25, 783.99, 1046.50];
    notes.forEach((f, i) => {
      setTimeout(() => this.playTone(f, 'sine', 0.8, 0.15), i * 150);
    });
  }

  // Magnet power-up pickup sound
  playMagnet() {
    this.playTone(400, 'sine', 0.5, 0.2, 800);
    setTimeout(() => this.playTone(600, 'sine', 0.4, 0.15, 1000), 100);
  }

  // Deep but soft underwater poof (instead of harsh explosion)
  playExplosion() {
    this.playTone(120, 'sine', 0.6, 0.4, 20);
    this.playTone(80, 'triangle', 0.8, 0.2, 10);
  }

  // Sweet gentle victory melody
  playVictory() {
    const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51];
    notes.forEach((f, i) => {
      setTimeout(() => this.playTone(f, 'sine', 0.5, 0.2), i * 100);
    });
  }

  // Soft interface click
  playClick() {
    this.playTone(900, 'sine', 0.04, 0.1);
  }

  // Magical shield sound
  playShield() {
    this.playTone(600, 'sine', 0.4, 0.2, 1200);
    setTimeout(() => this.playTone(800, 'sine', 0.4, 0.15, 1400), 100);
  }

  private startMusic() {
    if (this.musicInterval) return;
    
    const playNote = () => {
      if (this.isMuted || !this.ctx) return;
      // Gentle underwater background notes
      const scales = [261.63, 329.63, 392.00, 523.25];
      const note = scales[Math.floor(Math.random() * scales.length)];
      this.playTone(note, 'sine', 2.0, 0.03);
    };

    this.musicInterval = setInterval(playNote, 3000);
  }
}

export const audio = new AudioManager();
