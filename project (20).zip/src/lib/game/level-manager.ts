'use client';

/**
 * @fileOverview Manages level progression and difficulty scaling.
 * 
 * - InfiniteLevelManager: Tracks distance and levels for continuous gameplay modes.
 */

export class InfiniteLevelManager {
  private currentLevel: number = 1;
  private distanceInCurrentLevel: number = 0;
  
  // Base distance for Level 1 is 100m. Increases by 20m each level.
  private getLevelLength(level: number): number {
    return 100 + (level - 1) * 20;
  }

  constructor(startingLevel: number = 1) {
    this.currentLevel = startingLevel;
  }

  public update(speed: number, deltaTime: number) {
    // Convert units to "meters" for progress tracking
    this.distanceInCurrentLevel += Math.abs(speed) * deltaTime * 2;

    if (this.distanceInCurrentLevel >= this.getLevelLength(this.currentLevel)) {
      this.currentLevel++;
      this.distanceInCurrentLevel = 0;
    }
  }

  public getCurrentLevel(): number {
    return this.currentLevel;
  }

  public getDifficultyMultiplier(): number {
    return 1 + (this.currentLevel - 1) * 0.15;
  }

  public getProgress(): number {
    const length = this.getLevelLength(this.currentLevel);
    return Math.min(100, (this.distanceInCurrentLevel / length) * 100);
  }
}
