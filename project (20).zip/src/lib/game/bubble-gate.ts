import { DIRECTIONS, Vector, BubbleType } from './types';
import { CurrentSystem } from './current-system';

export class BubbleGate {
  x: number;
  y: number;
  type: BubbleType;
  radius: number = 28;
  used: boolean = false;

  constructor(x: number, y: number, type: BubbleType) {
    this.x = x;
    this.y = y;
    this.type = type;
  }

  activate(current: CurrentSystem, player: Vector, finish: Vector) {
    if (this.used) return;

    switch (this.type) {
      case "blue":
        current.rotateClockwise();
        break;

      case "pink":
        current.rotateCounterClockwise();
        break;

      case "yellow":
        current.strength *= 2;
        break;

      case "green":
        current.stop();
        setTimeout(() => {
          current.restore();
        }, 1000);
        break;

      case "rainbow":
        const dx = finish.x - player.x;
        const dy = finish.y - player.y;

        if (Math.abs(dx) > Math.abs(dy)) {
          current.direction = dx > 0 ? DIRECTIONS.RIGHT : DIRECTIONS.LEFT;
        } else {
          current.direction = dy > 0 ? DIRECTIONS.DOWN : DIRECTIONS.UP;
        }
        break;
    }

    this.used = true;
  }
}
