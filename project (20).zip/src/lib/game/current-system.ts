import { DIRECTIONS, Direction, Vector } from './types';

export class CurrentSystem {
  direction: Direction;
  strength: number;
  private readonly defaultStrength: number = 0.7;

  constructor(initialDirection: Direction = DIRECTIONS.RIGHT) {
    this.direction = initialDirection;
    this.strength = this.defaultStrength;
  }

  rotateClockwise() {
    this.direction = ((this.direction + 1) % 4) as Direction;
  }

  rotateCounterClockwise() {
    this.direction = ((this.direction + 3) % 4) as Direction;
  }

  stop() {
    this.strength = 0;
  }

  restore() {
    this.strength = this.defaultStrength;
  }

  getVector(): Vector {
    const vectors = [
      { x: 0, y: -1 }, // UP
      { x: 1, y: 0 },  // RIGHT
      { x: 0, y: 1 },  // DOWN
      { x: -1, y: 0 }  // LEFT
    ];
    
    const dirVec = vectors[this.direction];
    return { 
      x: dirVec.x * this.strength, 
      y: dirVec.y * this.strength 
    };
  }
}
