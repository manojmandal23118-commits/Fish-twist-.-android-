'use client';

export class GameProgressManager {
  private unlockedLevels: Record<string, number> = {
    'coral_lagoon': 1,
    'deep_sea': 1,
    'volcanic_reef': 1,
    'arctic_glacier': 1,
    'atlantis_ruins': 1,
    'toxic_swamp': 1
  };

  constructor() {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('tide_unlocked_levels_map');
      if (saved) {
        try {
          this.unlockedLevels = JSON.parse(saved);
        } catch (e) {
          console.error('Failed to parse progress', e);
        }
      }
    }
  }

  public getUnlockedLevel(biome: string): number {
    return this.unlockedLevels[biome] || 1;
  }

  public completeLevel(biome: string, completedLevel: number) {
    if (completedLevel >= (this.unlockedLevels[biome] || 1)) {
      this.unlockedLevels[biome] = completedLevel + 1;
      if (typeof window !== 'undefined') {
        localStorage.setItem('tide_unlocked_levels_map', JSON.stringify(this.unlockedLevels));
      }
    }
  }

  public resetProgress() {
    this.unlockedLevels = {
      'coral_lagoon': 1,
      'deep_sea': 1,
      'volcanic_reef': 1,
      'arctic_glacier': 1,
      'atlantis_ruins': 1,
      'toxic_swamp': 1
    };
    if (typeof window !== 'undefined') {
      localStorage.removeItem('tide_unlocked_levels_map');
    }
  }
}

export const progressManager = new GameProgressManager();
