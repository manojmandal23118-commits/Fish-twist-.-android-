
'use client';

import { GameState, LevelData, INITIAL_SKINS, SKIN_DATA } from './types';
import { GAME_MAPS } from './levels';
import { 
  drawBackground, 
  drawAmbientCreature, 
  drawPlayer, 
  drawFinishFeast, 
  drawDirectionIndicator,
  drawGrenade, 
  drawCoin,
  drawMagnet,
  drawHeart,
  drawJellyfish,
  drawBubble,
  drawSchoolFish,
  drawMonsterFish
} from './drawing-utils';
import { audio } from './audio';

export class GameEngine {
  public state: GameState = 'PLAYING';
  public width: number = 800;
  public height: number = 600;
  public worldWidth: number = 4000;
  public score: number = 0;
  public cherriesCollected: number = 0;
  public levelNumber: number = 1;
  public currentMap!: LevelData;
  public camera: { x: number; y: number } = { x: 0, y: 0 };
  public particles: any[] = [];
  
  public joystickInput: { x: number; y: number } | null = null;
  public touchTarget: { x: number; y: number } | null = null;
  
  public player: any = {
    x: 100, y: 300, vx: 0, vy: 0, radius: 18,
    skin: 'fish_1', targetX: 100, targetY: 300,
    isCelebrating: false, celebrationAngle: 0,
    facingLeft: false,
    angle: 0,
    magnetTimer: 0,
    hasShield: false
  };

  public level: any = {
    finishPos: { x: 3300, y: 300 },
    collectibles: [],
    obstacles: [],
    ambientCreatures: [],
    fishSchools: [],
    monsterFish: []
  };

  public onWinCallback?: () => void;
  public onGameOverCallback?: () => void;

  constructor(width: number, height: number, callbacks?: { onWin?: () => void; onGameOver?: () => void }) {
    this.width = width;
    this.height = height;
    this.onWinCallback = callbacks?.onWin;
    this.onGameOverCallback = callbacks?.onGameOver;
  }

  public loadMap(mapIndex: number) {
    this.levelNumber = mapIndex + 1;
    const mapIdx = mapIndex % GAME_MAPS.length;
    this.currentMap = GAME_MAPS[mapIdx];
    this.worldWidth = 4000 + (mapIndex * 500);

    this.player.x = 100;
    this.player.y = this.height / 2;
    this.player.targetX = 100;
    this.player.targetY = this.height / 2;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.facingLeft = false;
    this.player.angle = 0;
    this.player.magnetTimer = 0;
    this.player.hasShield = false;
    this.camera.x = 0;
    this.score = 0;
    this.cherriesCollected = 0;
    this.player.isCelebrating = false;
    this.particles = [];
    this.joystickInput = null;
    this.touchTarget = null;

    // Position finish point resting on seabed
    this.level.finishPos = { x: this.worldWidth - 300, y: this.height - 90 };
    
    const ambientTypes = [
      'rock', 'sharp_basalt', 'river_pebbles', 'crystal_rock', 
      'coral_bush', 'bulbous_shrub', 'fern_frond', 'anemone_shrub', 
      'snail', 'snail_2', 'turtle', 'tall_kelp', 'carpet_grass', 'ribbon_grass'
    ];
    
    this.level.ambientCreatures = Array.from({ length: 80 }, (_, i) => {
      const type = ambientTypes[i % ambientTypes.length];
      const isMobile = ['turtle', 'snail', 'snail_2'].includes(type);
      const isGround = !['turtle'].includes(type);
      
      return {
        type,
        x: 200 + Math.random() * (this.worldWidth - 600),
        y: isGround ? this.height - 70 : (100 + Math.random() * 300),
        vx: type === 'turtle' ? 1.5 : (type.includes('snail') ? 0.3 : 0),
        size: type.includes('rock') ? 25 + Math.random() * 10 : 18,
        direction: Math.random() > 0.5 ? 1 : -1
      };
    });

    const allSkinIds = Object.keys(SKIN_DATA);
    const totalSkins = allSkinIds.length;
    const minSpeciesCount = 8;
    const levelProgress = Math.min(1, (this.levelNumber - 1) / 100);
    const availableSpeciesCount = Math.floor(minSpeciesCount + (totalSkins - minSpeciesCount) * levelProgress);
    const availableSkinIds = allSkinIds.slice(0, availableSpeciesCount);

    const schoolCount = 22;
    this.level.fishSchools = Array.from({ length: schoolCount }, () => {
      const schoolSkinId = availableSkinIds[Math.floor(Math.random() * availableSkinIds.length)];
      const schoolSize = Math.floor(Math.random() * 5) + 1;

      return {
        x: Math.random() * this.worldWidth,
        y: 80 + Math.random() * (this.height - 200),
        vx: (Math.random() > 0.5 ? 1 : -1) * (0.8 + Math.random() * 1.5),
        fish: Array.from({ length: schoolSize }, () => ({
          dx: Math.random() * 90 - 45,
          dy: Math.random() * 70 - 35,
          sz: 10 + Math.random() * 8,
          ph: Math.random() * Math.PI * 2,
          skinId: schoolSkinId
        }))
      };
    });

    const level = this.levelNumber;
    let bombCount = 2;
    if (level <= 10) bombCount = 2;
    else if (level <= 20) bombCount = 4;
    else if (level <= 30) bombCount = 8;
    else if (level <= 40) bombCount = 10;
    else if (level <= 60) bombCount = 15;
    else if (level <= 80) bombCount = 20;
    else {
      const blocks = Math.floor((level - 81) / 10) + 1;
      bombCount = 20 + (blocks * 6);
    }

    const grenades = [];
    const minX = 800;
    const maxX = this.worldWidth - 1000;
    const spawnRange = maxX - minX;
    const segmentWidth = spawnRange / bombCount;

    for (let i = 0; i < bombCount; i++) {
      const segmentStart = minX + (i * segmentWidth);
      const x = segmentStart + (Math.random() * segmentWidth * 0.7);
      const y = 80 + Math.random() * (this.height - 200); 

      grenades.push({
        x,
        y,
        type: 'grenade' as const,
        radius: 20,
        collected: false
      });
    }

    // Path Logic for Coins, Magnets, and Hearts
    const pathItems = [];
    const pathStartX = 600;
    const pathEndX = this.worldWidth - 800;
    const centerY = this.height / 2 - 50; 
    const pathAmplitude = 120; 
    const pathFrequency = 0.0018; 
    
    // Coins in a structured curved line
    const coinSpacing = 110;
    for (let x = pathStartX; x <= pathEndX; x += coinSpacing) {
      const y = centerY + Math.sin(x * pathFrequency) * pathAmplitude;
      pathItems.push({
        x,
        y,
        type: 'coin' as const,
        radius: 12,
        collected: false
      });
    }

    // Magnets on the path
    const m1X = pathStartX + (pathEndX - pathStartX) * 0.35;
    const m2X = pathStartX + (pathEndX - pathStartX) * 0.75;
    [m1X, m2X].forEach(mx => {
      pathItems.push({
        x: mx,
        y: centerY + Math.sin(mx * pathFrequency) * pathAmplitude,
        type: 'magnet' as const,
        radius: 15,
        collected: false
      });
    });

    // Hearts on the path (Level-based spawning)
    let heartCount = 1;
    if (level > 10) heartCount = 2;
    if (level > 20) heartCount = 4;
    
    for (let i = 0; i < heartCount; i++) {
      const hX = pathStartX + (pathEndX - pathStartX) * ((i + 1) / (heartCount + 1));
      pathItems.push({
        x: hX,
        y: centerY + Math.sin(hX * pathFrequency) * pathAmplitude,
        type: 'heart' as const,
        radius: 18,
        collected: false
      });
    }

    this.level.collectibles = [...grenades, ...pathItems];

    this.level.obstacles = Array.from({ length: 15 }, (_, i) => ({
      x: 1000 + i * 500 + (Math.random() * 100),
      y: 60 + Math.random() * (this.height - 180),
      radius: 40,
      type: 'jellyfish',
      vx: (Math.random() > 0.5 ? 1 : -1) * (0.4 + Math.random() * 0.6),
      hue: Math.random() * 360
    }));

    let monsterCount = 0;
    if (level >= 100) monsterCount = 5;
    else if (level >= 80) monsterCount = 4;
    else if (level >= 60) monsterCount = 3;
    else if (level >= 40) monsterCount = 2;
    else if (level >= 25) monsterCount = 1;

    this.level.monsterFish = Array.from({ length: monsterCount }, () => ({
      x: this.worldWidth - 500 - (Math.random() * (this.worldWidth - 1000)),
      y: 100 + Math.random() * (this.height - 250),
      vx: 2.5 + Math.random() * 1.5,
      radius: 35,
      type: 'monster'
    }));
  }

  public setTarget(x: number, y: number) {
    this.touchTarget = { x, y };
  }

  public clearTarget() {
    this.touchTarget = null;
  }

  public update(dt: number) {
    if (this.state !== 'PLAYING') return;
    const ts = dt * 60; // Normalize time step to roughly 60fps
    
    const maxSpeed = 3.8; // Slightly reduced for smoother control
    const accelFactor = 0.12; // Adjusted for natural gliding feel
    
    let targetVx = 0;
    let targetVy = 0;
    let activeInput = false;

    // Dual control logic: Joystick has priority, then touch/tap target
    if (this.joystickInput && (Math.abs(this.joystickInput.x) > 0.1 || Math.abs(this.joystickInput.y) > 0.1)) {
      const inputX = this.joystickInput.x;
      const inputY = this.joystickInput.y;
      
      targetVx = inputX * maxSpeed;
      targetVy = inputY * maxSpeed;
      activeInput = true;
      this.touchTarget = null; 

      // Smooth rotation towards joystick direction
      const targetAngle = Math.atan2(inputY, inputX);
      let angleDiff = targetAngle - this.player.angle;
      while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
      while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
      this.player.angle += angleDiff * 0.18 * ts;
    } else if (this.touchTarget) {
      const dx = this.touchTarget.x - this.player.x;
      const dy = this.touchTarget.y - this.player.y;
      const dist = Math.hypot(dx, dy);

      if (dist > 8) {
        // Easing factor: fish slows down as it approaches the touch point
        const easing = Math.min(1, dist / 80);
        targetVx = (dx / dist) * maxSpeed * easing;
        targetVy = (dy / dist) * maxSpeed * easing;
        activeInput = true;

        // Smooth rotation towards target coordinate
        const targetAngle = Math.atan2(dy, dx);
        let angleDiff = targetAngle - this.player.angle;
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        this.player.angle += angleDiff * 0.15 * ts;
      } else {
        // Reached target coordinate, stop gliding
        this.touchTarget = null;
      }
    }

    if (activeInput) {
      this.player.vx += (targetVx - this.player.vx) * accelFactor * ts;
      this.player.vy += (targetVy - this.player.vy) * accelFactor * ts;
    } else {
      // Smooth deceleration for natural glide to stop
      const friction = Math.pow(0.88, ts);
      this.player.vx *= friction;
      this.player.vy *= friction;
      
      if (Math.hypot(this.player.vx, this.player.vy) < 0.05) {
        this.player.vx = 0;
        this.player.vy = 0;
      }
    }
    
    this.player.x += this.player.vx * ts;
    this.player.y += this.player.vy * ts;

    const currentSpeed = Math.hypot(this.player.vx, this.player.vy);
    if (currentSpeed > 1.0 && Math.random() < 0.35) {
      const bubbleAngle = this.player.angle + Math.PI;
      const spawnX = this.player.x + Math.cos(bubbleAngle) * 20;
      const spawnY = this.player.y + Math.sin(bubbleAngle) * 20;
      
      this.particles.push({
        x: spawnX,
        y: spawnY + (Math.random() * 20 - 10),
        vx: Math.cos(bubbleAngle) * 1.5 + (Math.random() - 0.5),
        vy: -0.5 - Math.random() * 0.5,
        size: 2 + Math.random() * 5,
        life: 1.0
      });
    }

    this.particles.forEach(p => {
      p.x += p.vx * ts;
      p.y += p.vy * ts;
      p.life -= 0.025 * ts;
    });
    this.particles = this.particles.filter(p => p.life > 0);

    // Screen Clamping - updated to allow movement all the way to top/bottom
    this.player.y = Math.max(this.player.radius, Math.min(this.height - this.player.radius, this.player.y));
    this.player.x = Math.max(this.player.radius, Math.min(this.worldWidth - this.player.radius, this.player.x));

    // Smooth camera tracking
    const targetCamX = Math.max(0, Math.min(this.worldWidth - this.width, this.player.x - this.width * 0.4));
    this.camera.x += (targetCamX - this.camera.x) * 0.15 * ts;

    this.level.fishSchools.forEach((school: any) => {
      school.x += school.vx * ts;
      if (school.x > this.worldWidth + 200) school.x = -200;
      if (school.x < -200) school.x = this.worldWidth + 200;
    });

    this.level.ambientCreatures.forEach((c: any) => {
      if (c.vx > 0) {
        c.x += c.vx * c.direction * ts;
        if (c.x > this.worldWidth + 100) c.x = -100;
        if (c.x < -100) c.x = this.worldWidth + 100;
      }
    });

    this.level.obstacles.forEach((obs: any) => {
      if (obs.type === 'jellyfish') {
        obs.x += obs.vx * ts;
        if (obs.x > this.worldWidth + 100) obs.x = -100;
        if (obs.x < -100) obs.x = this.worldWidth + 100;
      }
    });

    this.level.monsterFish?.forEach((m: any) => {
      m.x -= m.vx * ts;
      if (m.x < -200) m.x = this.worldWidth + 200;
      
      if (Math.hypot(this.player.x - m.x, this.player.y - m.y) < this.player.radius + m.radius) {
        if (this.player.hasShield) {
          this.player.hasShield = false;
          m.x = -500; 
          audio.playExplosion();
        } else {
          this.state = 'GAME_OVER';
          audio.playExplosion();
          if (this.onGameOverCallback) this.onGameOverCallback();
        }
      }
    });

    if (this.player.magnetTimer > 0) {
      this.player.magnetTimer -= ts;
      this.level.collectibles.forEach((item: any) => {
        if (item.type === 'coin' && !item.collected) {
          const dx = this.player.x - item.x;
          const dy = this.player.y - item.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 400) {
            const pullSpeed = 9 * ts;
            item.x += (dx / dist) * pullSpeed;
            item.y += (dy / dist) * pullSpeed;
          }
        }
      });
    }

    this.level.collectibles.forEach((item: any) => {
      if (!item.collected && Math.hypot(this.player.x - item.x, this.player.y - item.y) < this.player.radius + item.radius) {
        if (item.type === 'grenade') {
          if (this.player.hasShield) {
            item.collected = true;
            this.player.hasShield = false;
            audio.playExplosion();
          } else {
            item.collected = true;
            this.state = 'GAME_OVER';
            audio.playExplosion();
            if (this.onGameOverCallback) this.onGameOverCallback();
          }
        } else if (item.type === 'magnet') {
          item.collected = true;
          this.player.magnetTimer = 600; 
          audio.playMagnet();
        } else if (item.type === 'heart') {
          item.collected = true;
          this.player.hasShield = true;
          audio.playShield();
        } else if (item.type === 'coin') {
          item.collected = true;
          this.score += 10;
          audio.playPop();
        }
      }
    });

    if (!this.player.isCelebrating && Math.hypot(this.player.x - this.level.finishPos.x, this.player.y - this.level.finishPos.y) < 65) {
      this.player.isCelebrating = true;
      audio.playVictory();
      setTimeout(() => { 
        this.state = 'WIN'; 
        if (this.onWinCallback) this.onWinCallback(); 
      }, 2000);
    }
  }

  public render(ctx: CanvasRenderingContext2D) {
    const time = Date.now();
    drawBackground(ctx, this.width, this.height, time, this.camera.x, this.currentMap);

    ctx.save();
    ctx.translate(-this.camera.x, 0);

    this.level.fishSchools.forEach((school: any) => {
      school.fish.forEach((f: any) => {
        const fx = school.x + f.dx;
        const fy = school.y + f.dy + Math.sin(time * 0.002 + f.ph) * 10;
        if (fx > this.camera.x - 200 && fx < this.camera.x + this.width + 200) {
          drawSchoolFish(ctx, fx, fy, f.sz, f.skinId, school.vx > 0 ? 0 : Math.PI, time);
        }
      });
    });

    this.level.ambientCreatures.forEach((c: any) => drawAmbientCreature(ctx, c, time));
    this.particles.forEach(p => drawBubble(ctx, p.x, p.y, p.size, p.life));

    this.level.collectibles.forEach((item: any) => {
      if (!item.collected) {
        if (item.type === 'coin') drawCoin(ctx, item.x, item.y, item.radius, time);
        else if (item.type === 'grenade') drawGrenade(ctx, item.x, item.y, item.radius, time);
        else if (item.type === 'magnet') drawMagnet(ctx, item.x, item.y, item.radius, time);
        else if (item.type === 'heart') drawHeart(ctx, item.x, item.y, item.radius, time);
      }
    });

    this.level.obstacles.forEach((obs: any) => {
      if (obs.type === 'jellyfish') {
        drawJellyfish(ctx, obs.x, obs.y, obs.radius, time, obs.hue);
      }
    });

    this.level.monsterFish?.forEach((m: any) => {
      drawMonsterFish(ctx, m.x, m.y, m.radius, time);
    });

    drawFinishFeast(ctx, this.level.finishPos, time, this.levelNumber);
    drawPlayer(ctx, this.player);

    ctx.restore();
  }
}
