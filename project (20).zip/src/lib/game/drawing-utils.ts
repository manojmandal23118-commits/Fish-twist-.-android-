import { SKIN_DATA, INITIAL_SKINS } from './types';
import { LevelData } from './levels';

/**
 * @fileOverview Refined anatomical rendering system for 75 unique species and 13 ambient objects.
 * Features 50+ unique body shapes and structural designs.
 */

export function drawBackground(ctx: CanvasRenderingContext2D, width: number, height: number, time: number, cameraX: number, currentMap?: LevelData) {
  const waterColors = currentMap?.waterColors || ['#0077B6', '#0096C7', '#001220'];
  const sandColor = currentMap?.sandColor || '#C29B38';
  const sunrayColor = currentMap?.sunrayColor || '#00F5D4';

  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, waterColors[0]);
  grad.addColorStop(0.4, waterColors[1]);
  grad.addColorStop(1, waterColors[2]);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.globalAlpha = 0.15;
  for (let i = 0; i < 8; i++) {
    const rx = ((width / 7) * i + Math.sin(time * 0.0008 + i) * 60) - (cameraX * 0.1 % width);
    const rGrad = ctx.createLinearGradient(rx, 0, rx + 100, height);
    rGrad.addColorStop(0, sunrayColor);
    rGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = rGrad;
    ctx.beginPath();
    ctx.moveTo(rx - 40, 0);
    ctx.lineTo(rx + 60, 0);
    ctx.lineTo(rx + 180, height);
    ctx.lineTo(rx - 80, height);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  const seabedY = height - 65;
  ctx.save();
  ctx.translate(-cameraX % 40, 0);
  ctx.fillStyle = sandColor;
  ctx.beginPath();
  ctx.moveTo(-40, seabedY);
  for (let x = -40; x <= width + 80; x += 40) {
    ctx.lineTo(x, seabedY + Math.sin((x + cameraX) * 0.015) * 10);
  }
  ctx.lineTo(width + 80, height);
  ctx.lineTo(-40, height);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/**
 * Procedurally draws a fish based on its structural shape archetype.
 */
function drawFishBody(ctx: CanvasRenderingContext2D, s: number, colors: any, shape: string, time: number, isMoving: boolean, speed: number = 0) {
  const wiggleFreq = 0.006 + (speed * 0.002);
  const wiggleAmp = 0.08 + (speed * 0.02);
  const tailSway = Math.sin(time * wiggleFreq) * (s * 0.4 + (isMoving ? speed * 2 : 2));

  ctx.fillStyle = colors.primary;
  ctx.strokeStyle = colors.accent;
  ctx.lineWidth = 1;

  switch (shape) {
    case 'clownfish':
      // Classic oval body with white bands
      ctx.beginPath();
      ctx.moveTo(s * 1.2, 0);
      ctx.bezierCurveTo(s * 0.8, -s * 0.9, -s * 0.8, -s * 0.9, -s * 1.1, 0);
      ctx.bezierCurveTo(-s * 0.8, s * 0.9, s * 0.8, s * 0.9, s * 1.2, 0);
      ctx.fill();
      // White bands
      ctx.fillStyle = 'white';
      ctx.beginPath(); ctx.ellipse(s * 0.4, 0, s * 0.2, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-s * 0.2, 0, s * 0.15, s * 0.7, 0, 0, Math.PI * 2); ctx.fill();
      // Tail
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 2, -s * 0.9 + tailSway); ctx.lineTo(-s * 2, s * 0.9 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'standard':
      ctx.beginPath();
      ctx.moveTo(s * 1.2, 0);
      ctx.bezierCurveTo(s * 0.8, -s * 0.9, -s * 0.8, -s * 0.9, -s * 1.1, 0);
      ctx.bezierCurveTo(-s * 0.8, s * 0.9, s * 0.8, s * 0.9, s * 1.2, 0);
      ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 2, -s * 0.9 + tailSway); ctx.lineTo(-s * 2, s * 0.9 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'goldfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.3, s * 1.1, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 2.2, -s * 1.2 + tailSway); ctx.lineTo(-s * 1.8, 0); ctx.lineTo(-s * 2.2, s * 1.2 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'guppy':
      ctx.beginPath(); ctx.ellipse(s * 0.2, 0, s * 0.8, s * 0.4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.4, 0); ctx.quadraticCurveTo(-s * 2.5, -s * 1.8 + tailSway, -s * 2.8, tailSway); ctx.quadraticCurveTo(-s * 2.5, s * 1.8 + tailSway, -s * 0.4, 0); ctx.fill();
      break;

    case 'tang':
      ctx.beginPath(); ctx.moveTo(s * 1.1, 0); ctx.bezierCurveTo(s * 0.7, -s * 1.2, -s * 0.5, -s * 1.2, -s * 0.9, 0); ctx.bezierCurveTo(-s * 0.5, s * 1.2, s * 0.7, s * 1.2, s * 1.1, 0); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 1.8, -s * 0.7 + tailSway); ctx.lineTo(-s * 1.8, s * 0.7 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'tetra':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 0.9, s * 0.35, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.accent; ctx.beginPath(); ctx.rect(-s * 0.9, -s * 0.05, s * 1.8, s * 0.1); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 1.4, -s * 0.4 + tailSway); ctx.lineTo(-s * 1.4, s * 0.4 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'discus':
      ctx.beginPath(); ctx.arc(0, 0, s * 1.3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 1.6, -s * 0.5 + tailSway); ctx.lineTo(-s * 1.6, s * 0.5 + tailSway); ctx.fill();
      break;

    case 'angelfish':
    case 'emperorAngelfish':
    case 'butterflyfish':
    case 'moorishIdol':
      const tallFactor = (shape === 'angelfish' || shape === 'moorishIdol') ? 1.8 : 1.4;
      ctx.beginPath();
      ctx.ellipse(0, 0, s, s * tallFactor, 0, 0, Math.PI * 2);
      ctx.fill();
      if (shape === 'moorishIdol') {
        ctx.fillStyle = colors.secondary;
        ctx.beginPath(); ctx.moveTo(0, -s * tallFactor); ctx.lineTo(-s * 1.5, -s * 3.5 + tailSway); ctx.lineTo(-s * 0.3, -s * tallFactor); ctx.fill();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s, 0); ctx.lineTo(-s * 2, -s * 0.8 + tailSway); ctx.lineTo(-s * 2, s * 0.8 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'betta':
    case 'phoenixFish':
    case 'sovereignFish':
    case 'oceanGodfish':
      ctx.beginPath(); ctx.ellipse(s * 0.4, 0, s * 0.7, s * 0.4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      const finLen = shape === 'oceanGodfish' ? 4.5 : (shape === 'phoenixFish' ? 4 : 2.5);
      ctx.beginPath(); ctx.moveTo(0, -s * 0.4); ctx.bezierCurveTo(-s, -s * finLen, -s * finLen, -s, -s * 1.8, 0); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0, s * 0.4); ctx.bezierCurveTo(-s, s * finLen, -s * finLen, s, -s * 1.8, 0); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-s * 0.5, 0); ctx.bezierCurveTo(-s * 2.5, -s * 2.5, -s * 5, 0, -s * 2.5, s * 2.5); ctx.fill();
      break;

    case 'swordfish':
    case 'marlin':
    case 'sailfish':
      ctx.beginPath();
      ctx.ellipse(0, 0, s * 1.5, s * 0.6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = colors.accent; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(s * 1.5, 0); ctx.lineTo(s * 3.8, 0); ctx.stroke();
      if (shape === 'sailfish') {
        ctx.fillStyle = colors.secondary;
        ctx.beginPath(); ctx.moveTo(-s * 0.8, -s * 0.6); ctx.quadraticCurveTo(0, -s * 3.5, s * 1.2, -s * 0.5); ctx.fill();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.5, 0); ctx.lineTo(-s * 2.8, -s + tailSway); ctx.lineTo(-s * 2.8, s + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'lionfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.1, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.secondary; ctx.lineWidth = 2.5;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 1.5 - Math.PI * 0.75;
        ctx.beginPath(); ctx.moveTo(Math.cos(a) * s * 0.8, Math.sin(a) * s * 0.8);
        ctx.lineTo(Math.cos(a) * s * 2.2, Math.sin(a) * s * 2.2);
        ctx.stroke();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 0.8, 0); ctx.lineTo(-s * 2.2, -s * 1.2 + tailSway); ctx.lineTo(-s * 2.2, s * 1.2 + tailSway); ctx.fill();
      break;

    case 'sawfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.8, s * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.rect(s * 1.8, -s * 0.2, s * 2.2, s * 0.4); ctx.fill();
      for (let i = 0; i < 6; i++) {
        ctx.beginPath(); ctx.rect(s * (2.0 + i * 0.35), -s * 0.35, s * 0.1, s * 0.7); ctx.fill();
      }
      ctx.beginPath(); ctx.moveTo(-s * 1.8, 0); ctx.lineTo(-s * 2.8, -s * 0.8 + tailSway); ctx.lineTo(-s * 2.8, s * 0.8 + tailSway); ctx.fill();
      break;

    case 'flyingFish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.3, s * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      const flySway = Math.sin(time * 0.01) * s * 0.5;
      ctx.beginPath(); ctx.ellipse(s * 0.2, -s * 0.4, s * 1.2, s * 0.6 + flySway, -0.2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s * 0.2, s * 0.4, s * 1.2, s * 0.6 + flySway, 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-s * 1.3, 0); ctx.lineTo(-s * 2.2, -s * 0.7 + tailSway); ctx.lineTo(-s * 2.2, s * 0.7 + tailSway); ctx.fill();
      break;

    case 'nautilus':
      const shellGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, s * 1.5);
      shellGrad.addColorStop(0, colors.primary); shellGrad.addColorStop(1, colors.secondary);
      ctx.fillStyle = shellGrad;
      ctx.beginPath(); ctx.arc(0, 0, s * 1.5, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.accent; ctx.lineWidth = 1.5;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s * 1.5, Math.sin(a) * s * 1.5); ctx.stroke();
      }
      ctx.fillStyle = colors.primary;
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 0.5 - Math.PI * 0.25;
        ctx.beginPath(); ctx.ellipse(s * 1.4, Math.sin(a) * s * 0.5, s * 0.8, s * 0.15, a, 0, Math.PI * 2); ctx.fill();
      }
      break;

    case 'cuttlefish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.4, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.secondary; ctx.lineWidth = 2;
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        const tx = Math.cos(a) * s * 1.4;
        const ty = Math.sin(a) * s * 0.9;
        ctx.beginPath(); ctx.arc(tx, ty, 3, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = colors.secondary;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.ellipse(s * 1.4, -s * 0.2 + i * s * 0.15, s * 0.4, s * 0.1, 0, 0, Math.PI * 2); ctx.fill();
      }
      break;

    case 'fireGoby':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.8, s * 0.35, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(s * 0.5, -s * 0.3); ctx.lineTo(s * 0.4, -s * 2.2); ctx.lineTo(s * 0.7, -s * 0.3); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-s * 1.5, 0); ctx.lineTo(-s * 2.5, -s * 0.5 + tailSway); ctx.lineTo(-s * 2.5, s * 0.5 + tailSway); ctx.fill();
      break;

    case 'koi':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.6, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.secondary; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(s * 1.4, 0.2 * s); ctx.quadraticCurveTo(s * 1.8, 0.6 * s, s * 1.6, s); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(s * 1.4, -0.2 * s); ctx.quadraticCurveTo(s * 1.8, -0.6 * s, s * 1.6, -s); ctx.stroke();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.4, 0); ctx.lineTo(-s * 2.5, -s + tailSway); ctx.lineTo(-s * 2.5, s + tailSway); ctx.fill();
      break;

    case 'icefish':
      ctx.save(); ctx.globalAlpha = 0.5;
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.4, s * 0.4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'white';
      ctx.beginPath(); ctx.moveTo(-s * 1.0, 0); ctx.lineTo(-s * 1.8, -s * 0.6 + tailSway); ctx.lineTo(-s * 1.8, s * 0.6 + tailSway); ctx.fill();
      ctx.restore();
      break;

    case 'manta':
    case 'stingray':
    case 'electricRay':
    case 'hammerheadRay':
      ctx.beginPath();
      ctx.ellipse(0, 0, s * 1.3, s * 2.5, Math.PI / 2, 0, Math.PI * 2);
      ctx.fill();
      if (shape === 'hammerheadRay') {
        ctx.beginPath(); ctx.rect(s * 0.8, -s * 2, s * 0.5, s * 4); ctx.fill();
      }
      ctx.strokeStyle = colors.accent; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-s * 1.3, 0); ctx.quadraticCurveTo(-s * 3, tailSway, -s * 4.5, tailSway * 0.5); ctx.stroke();
      break;

    case 'hammerhead':
    case 'greatWhite':
    case 'megalodon':
      const sharkS = shape === 'megalodon' ? 2.5 : (shape === 'greatWhite' ? 2.0 : 1.8);
      ctx.beginPath(); ctx.ellipse(0, 0, s * sharkS, s * 0.7, 0, 0, Math.PI * 2); ctx.fill();
      if (shape === 'hammerhead') {
        ctx.beginPath(); ctx.rect(s * 1.2, -s * 1.6, s * 0.6, s * 3.2); ctx.fill();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(0, -s * 0.6); ctx.lineTo(-s * 0.8, -s * 1.8 + tailSway * 0.3); ctx.lineTo(-s * 0.4, -s * 0.6); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-s * sharkS * 0.8, 0); ctx.lineTo(-s * (sharkS + 1.2), -s * 1.3 + tailSway); ctx.lineTo(-s * (sharkS + 1.2), s * 1.3 + tailSway); ctx.closePath(); ctx.fill();
      break;

    case 'barracuda':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 2.5, s * 0.45, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 2.2, 0); ctx.lineTo(-s * 3.4, -s * 0.6 + tailSway); ctx.lineTo(-s * 3.4, s * 0.6 + tailSway); ctx.fill();
      break;

    case 'lanternfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.3, s * 0.7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#00F5D4';
      for (let i = 0; i < 5; i++) {
        ctx.beginPath(); ctx.arc(-s + i * s * 0.4, s * 0.4, 2, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.3, 0); ctx.lineTo(-s * 2.2, -s * 0.7 + tailSway); ctx.lineTo(-s * 2.2, s * 0.7 + tailSway); ctx.fill();
      break;

    case 'coelacanth':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.8, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * s, Math.sin(a) * s * 0.8, s * 0.6, s * 0.3, a, 0, Math.PI * 2); ctx.fill();
      }
      ctx.beginPath(); ctx.moveTo(-s * 1.5, 0); ctx.lineTo(-s * 2.8, -s * 1.1 + tailSway); ctx.lineTo(-s * 2.8, s * 1.1 + tailSway); ctx.fill();
      break;

    case 'ventFish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.2, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.accent; ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.arc(Math.random() * s - s / 2, Math.random() * s - s / 2, 3, 0, Math.PI * 2); ctx.stroke();
      }
      break;

    case 'wrasse':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.8, s * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.5, 0); ctx.lineTo(-s * 2.8, -s * 0.4 + tailSway); ctx.lineTo(-s * 2.8, s * 0.4 + tailSway); ctx.fill();
      break;

    case 'dunkleosteus':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.8, s * 1.0, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.rect(s * 0.5, -s * 1.0, s * 1.5, s * 2.0); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.6, 0); ctx.lineTo(-s * 2.8, -s * 1.2 + tailSway); ctx.lineTo(-s * 2.8, s * 1.2 + tailSway); ctx.fill();
      break;

    case 'leviathan':
    case 'dragonWyrm':
      const levL = shape === 'leviathan' ? 6 : 5;
      ctx.beginPath(); ctx.moveTo(s * 2, 0);
      for (let i = 0; i < 20; i++) {
        const x = s * 2 - (i * s * levL / 20);
        const y = Math.sin(time * 0.005 + i * 0.3) * s * 0.8;
        ctx.lineTo(x, y);
      }
      ctx.lineWidth = s * 1.1; ctx.strokeStyle = colors.primary; ctx.stroke();
      ctx.fillStyle = colors.accent; ctx.beginPath(); ctx.arc(s * 2, -s * 0.6, s * 0.5, 0, Math.PI * 2); ctx.fill();
      break;

    case 'mandarinFish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.2, s * 1.0, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.ellipse(0, -s * 1.2, s * 0.8, s * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-s * 0.5, 0, s * 0.9, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
      break;

    case 'triggerfish':
      ctx.beginPath(); ctx.moveTo(s * 1.5, 0); ctx.lineTo(0, -s * 1.4); ctx.lineTo(-s * 1.5, 0); ctx.lineTo(0, s * 1.4); ctx.closePath(); ctx.fill();
      ctx.fillStyle = colors.secondary; ctx.beginPath(); ctx.moveTo(-s * 1.2, 0); ctx.lineTo(-s * 2.2, -s * 0.6 + tailSway); ctx.lineTo(-s * 2.2, s * 0.6 + tailSway); ctx.fill();
      break;

    case 'tuna':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 2.0, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.accent;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath(); ctx.moveTo(-s * 1.2 - i * s * 0.2, -s * 0.5); ctx.lineTo(-s * 1.4 - i * s * 0.2, -s * 0.8); ctx.stroke();
      }
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.8, 0); ctx.lineTo(-s * 3.0, -s + tailSway); ctx.lineTo(-s * 3.0, s + tailSway); ctx.fill();
      break;

    case 'cookiecutterShark':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.5, s * 0.4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#00F5D4'; ctx.beginPath(); ctx.ellipse(0, s * 0.2, s * 0.8, s * 0.15, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.4, 0); ctx.lineTo(-s * 2.2, -s * 0.5 + tailSway); ctx.lineTo(-s * 2.2, s * 0.5 + tailSway); ctx.fill();
      break;

    case 'flyingSquid':
      ctx.beginPath(); ctx.ellipse(s * 0.6, 0, s * 1.3, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.ellipse(s * 0.4, -s * 0.8, s * 1.2, s * 0.4, -0.3, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s * 0.4, s * 0.8, s * 1.2, s * 0.4, 0.3, 0, Math.PI * 2); ctx.fill();
      for (let i = 0; i < 8; i++) {
        const a = Math.PI + (i / 8) * Math.PI - Math.PI / 2;
        ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(Math.cos(a) * s * 3.5 - s, Math.sin(a) * s * 0.6); ctx.stroke();
      }
      break;

    case 'leafyGoblinfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.4, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        ctx.beginPath(); ctx.ellipse(Math.cos(a) * s * 1.2, Math.sin(a) * s * 0.8, s * 0.5, s * 0.2, a, 0, Math.PI * 2); ctx.fill();
      }
      break;

    case 'blueRingedOctopus':
      ctx.beginPath(); ctx.ellipse(s * 0.6, 0, s * 1.2, s * 0.9, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#00F5D4'; ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        ctx.beginPath(); ctx.arc(Math.random() * s - s / 2, Math.random() * s - s / 2, 4, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.fillStyle = colors.secondary;
      for (let i = 0; i < 8; i++) {
        const a = Math.PI + (i / 8) * Math.PI - Math.PI / 2;
        ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(Math.cos(a) * s * 3.5 - s, Math.sin(a) * s * 0.6); ctx.stroke();
      }
      break;

    case 'cosmicNebula':
    case 'auroraPhantom':
    case 'timewarpLeviathan':
    case 'crystalDragonfish':
      ctx.save(); ctx.globalAlpha = 0.7;
      ctx.beginPath(); ctx.ellipse(0, 0, s * 2.0, s * 1.0, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'white';
      for (let i = 0; i < 10; i++) {
        ctx.beginPath(); ctx.arc(Math.random() * s * 3 - s * 1.5, Math.random() * s * 1.5 - s * 0.75, 1.5, 0, Math.PI * 2); ctx.fill();
      }
      if (shape === 'timewarpLeviathan') {
        ctx.strokeStyle = colors.accent; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.ellipse(0, 0, s * 2.8, s * 1.5, time * 0.002, 0, Math.PI * 2); ctx.stroke();
      }
      if (shape === 'crystalDragonfish') {
        ctx.strokeStyle = colors.accent; ctx.lineWidth = 1.5;
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s * 2.2, Math.sin(a) * s * 1.2); ctx.stroke();
        }
      }
      ctx.restore();
      break;

    case 'eel':
    case 'morayEel':
    case 'snake':
    case 'ribbonEel':
    case 'oarfish':
    case 'dragonfish':
      const len = shape === 'oarfish' ? 7 : (shape === 'ribbonEel' ? 6 : 4.5);
      ctx.beginPath();
      ctx.moveTo(s * 1.5, 0);
      for (let i = 0; i < 15; i++) {
        const x = s * 1.5 - (i * s * len / 15);
        const y = Math.sin(time * 0.005 + i * 0.4) * s * 0.6;
        ctx.lineTo(x, y);
      }
      ctx.lineWidth = s * 0.8;
      ctx.lineCap = 'round';
      ctx.strokeStyle = colors.primary; ctx.stroke();
      break;

    case 'pufferfish':
      ctx.beginPath(); ctx.arc(0, 0, s * 1.3, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = colors.accent;
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * Math.PI * 2;
        ctx.beginPath(); ctx.moveTo(Math.cos(a) * s * 1.3, Math.sin(a) * s * 1.3);
        ctx.lineTo(Math.cos(a) * s * 1.6, Math.sin(a) * s * 1.6);
        ctx.stroke();
      }
      break;

    case 'seahorse':
    case 'seadragon':
    case 'weedySeadragon':
      ctx.save(); ctx.rotate(-Math.PI / 2);
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.6, s * 0.7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(-s * 1.6, s * 0.6, s * 0.9, 0, Math.PI, false); ctx.stroke();
      ctx.beginPath(); ctx.rect(s * 1.5, -s * 0.25, s * 1.2, s * 0.5); ctx.fill();
      if (shape.includes('dragon')) {
        ctx.fillStyle = colors.secondary;
        for (let i = 0; i < 3; i++) {
            ctx.beginPath(); ctx.arc(-s + i * s, -s * 0.6, s * 0.4, 0, Math.PI); ctx.fill();
        }
      }
      ctx.restore();
      break;

    case 'jellyfish':
      ctx.beginPath(); ctx.arc(0, 0, s, Math.PI, 0); ctx.fill();
      ctx.strokeStyle = colors.secondary;
      for (let i = 0; i < 6; i++) {
        const tx = -s + (i * s * 0.4);
        const ty = Math.sin(time * 0.005 + i) * 12;
        ctx.beginPath(); ctx.moveTo(tx, 0); ctx.quadraticCurveTo(tx + ty, s * 1.8, tx, s * 3.5); ctx.stroke();
      }
      break;

    case 'squid':
    case 'octopus':
    case 'kraken':
    case 'dumboOctopus':
      ctx.beginPath(); ctx.ellipse(s * 0.6, 0, s * 1.3, s * 0.8, 0, 0, Math.PI * 2); ctx.fill();
      if (shape === 'dumboOctopus') {
          ctx.fillStyle = colors.secondary;
          ctx.beginPath(); ctx.ellipse(s * 0.5, -s * 0.7, s * 0.6, s * 0.4, -0.5, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.ellipse(s * 0.5, s * 0.7, s * 0.6, s * 0.4, 0.5, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = colors.secondary;
      for (let i = 0; i < 8; i++) {
        const a = Math.PI + (i / 8) * Math.PI - Math.PI / 2;
        const tx = Math.cos(a) * s * 3.2;
        const ty = Math.sin(a) * s * 0.6 + Math.sin(time * 0.005 + i) * 6;
        ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(tx - s, ty); ctx.stroke();
      }
      break;

    case 'turtle':
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.6, s * 1.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.primary;
      const fSway = Math.sin(time * 0.005) * 0.6;
      ctx.beginPath(); ctx.ellipse(s * 0.9, -s * 1.3, s * 0.9, s * 0.5, 0.6 + fSway, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s * 0.9, s * 1.3, s * 0.9, s * 0.5, -0.6 - fSway, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(s * 2, 0, s * 0.6, 0, Math.PI * 2); ctx.fill();
      break;

    case 'whale':
    case 'orca':
    case 'narwhal':
    case 'whaleShark':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 2.2, s * 1.0, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 2.2, 0); ctx.lineTo(-s * 3.2, -s * 1.2 + tailSway); ctx.lineTo(-s * 3.2, s * 1.2 + tailSway); ctx.fill();
      if (shape === 'narwhal') {
        ctx.strokeStyle = '#eee'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(s * 2.2, -s * 0.3); ctx.lineTo(s * 4.8, -s * 0.3); ctx.stroke();
      }
      break;

    case 'mola':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.1, s * 1.8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(0, -s * 1.8); ctx.lineTo(-s * 0.8, -s * 2.8 + tailSway); ctx.lineTo(-s * 0.4, -s * 1.8); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0, s * 1.8); ctx.lineTo(-s * 0.8, s * 2.8 - tailSway); ctx.lineTo(-s * 0.4, s * 1.8); ctx.fill();
      break;

    case 'clam':
      ctx.beginPath(); ctx.arc(0, 0, s * 1.5, Math.PI, 0); ctx.fill();
      ctx.beginPath(); ctx.arc(0, 0, s * 1.5, 0, Math.PI); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = 2;
      for (let i = 0; i < 5; i++) {
          const a = (i / 5) * Math.PI;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * s * 1.5, Math.sin(a) * s * 1.5); ctx.stroke();
      }
      break;

    case 'blobfish':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.5, s * 1.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.arc(s * 0.6, s * 0.2, s * 0.4, 0, Math.PI * 2); ctx.fill(); // big nose
      ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.arc(s * 0.6, s * 0.5, s * 0.3, 0.2 * Math.PI, 0.8 * Math.PI); ctx.stroke(); // frown
      break;

    case 'anglerfish':
    case 'viperfish':
    case 'goblinShark':
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.6, s * 1.2, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'white'; // Teeth
      for (let i = 0; i < 5; i++) {
          ctx.beginPath(); ctx.moveTo(s * (0.8 + i * 0.15), 0); ctx.lineTo(s * (0.9 + i * 0.15), s * 0.6); ctx.lineTo(s * (0.7 + i * 0.15), s * 0.6); ctx.fill();
      }
      if (shape === 'anglerfish') {
          ctx.strokeStyle = colors.accent; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(s, -s * 0.8); ctx.quadraticCurveTo(s * 2, -s * 2, s * 2.2, -s * 1.2); ctx.stroke();
          ctx.fillStyle = colors.accent; ctx.beginPath(); ctx.arc(s * 2.2, -s * 1.2, 4, 0, Math.PI * 2); ctx.fill();
      }
      break;

    default:
      // Generic fish fallback
      ctx.beginPath(); ctx.ellipse(0, 0, s * 1.2, s * 0.7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = colors.secondary;
      ctx.beginPath(); ctx.moveTo(-s * 1.2, 0); ctx.lineTo(-s * 2.2, -s * 0.8 + tailSway); ctx.lineTo(-s * 2.2, s * 0.8 + tailSway); ctx.closePath(); ctx.fill();
  }

  // Eye (common for most)
  if (shape !== 'clam' && shape !== 'jellyfish') {
    const isAngry = ['greatWhite', 'megalodon', 'barracuda', 'viperfish', 'monster', 'anglerfish', 'goblinShark', 'kraken', 'dunkleosteus'].includes(shape);
    ctx.fillStyle = 'white'; 
    ctx.beginPath(); 
    ctx.arc(s * 0.8, -s * 0.25, s * 0.25, 0, Math.PI * 2); 
    ctx.fill();
    
    ctx.fillStyle = isAngry ? colors.accent : 'black'; 
    ctx.beginPath(); 
    ctx.arc(s * 0.9, -s * 0.25, s * 0.12, 0, Math.PI * 2); 
    ctx.fill();
    
    if (isAngry) {
        ctx.strokeStyle = 'black'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(s * 0.6, -s * 0.5); ctx.lineTo(s * 1.1, -s * 0.3); ctx.stroke();
    }
  }
}

export function drawTallKelp(ctx: CanvasRenderingContext2D, x: number, y: number, time: number, xSeed: number) {
  const numBlades = 2 + (xSeed % 2);
  for (let j = 0; j < numBlades; j++) {
    const bladeSway = Math.sin(time * 0.002 + xSeed + j) * (18 + j * 5);
    const bladeHeight = 90 + (xSeed % 50) + j * 15;
    const offsetX = (j - 1) * 5;
    ctx.strokeStyle = (xSeed + j) % 2 === 0 ? '#065F46' : '#059669'; 
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x + offsetX, y);
    ctx.bezierCurveTo(x + offsetX + bladeSway * 0.3, y - bladeHeight * 0.4, x + offsetX + bladeSway * 0.7, y - bladeHeight * 0.8, x + offsetX + bladeSway, y - bladeHeight);
    ctx.stroke();
  }
}

export function drawShortCarpetGrass(ctx: CanvasRenderingContext2D, x: number, y: number, time: number, xSeed: number) {
  const numBlades = 8 + (xSeed % 6);
  for (let i = 0; i < numBlades; i++) {
    const offsetX = (i - numBlades / 2) * 5;
    const h = 15 + (Math.sin(xSeed * 0.5 + i) * 8);
    const sway = Math.sin(time * 0.004 + xSeed + i) * 3;
    ctx.strokeStyle = (i % 3 === 0) ? '#34D399' : (i % 3 === 1 ? '#10B981' : '#059669');
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x + offsetX, y);
    ctx.quadraticCurveTo(x + offsetX + sway * 0.5, y - h * 0.5, x + offsetX + sway, y - h);
    ctx.stroke();
  }
}

export function drawCurlyRibbonGrass(ctx: CanvasRenderingContext2D, x: number, y: number, time: number, xSeed: number) {
  const h = 60 + (xSeed % 40);
  const sway = Math.sin(time * 0.0025 + xSeed) * 25;
  ctx.strokeStyle = '#BEF264';
  ctx.lineWidth = 4.5;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.bezierCurveTo(x + sway * 0.3, y - h * 0.35, x - sway * 0.3, y - h * 0.65, x + sway, y - h);
  ctx.stroke();
}

export function drawSnail(ctx: CanvasRenderingContext2D, type: string, time: number, size: number) {
  const s = size || 15;
  const crawl = Math.sin(time * 0.002) * 2;
  
  ctx.save();
  ctx.translate(crawl, 0);

  // Slimy Snail Body (Creeping part)
  ctx.fillStyle = '#CBD5E1'; // Slate 300
  ctx.beginPath();
  ctx.ellipse(0, s * 0.4, s * 1.3, s * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Head with small antennas
  ctx.beginPath();
  ctx.arc(s * 1.1, s * 0.2, s * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 1;
  ctx.strokeStyle = '#94A3B8';
  ctx.beginPath(); ctx.moveTo(s * 1.2, s * 0.1); ctx.lineTo(s * 1.4, -s * 0.2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(s * 1.0, s * 0.1); ctx.lineTo(s * 1.1, -s * 0.2); ctx.stroke();

  if (type === 'snail') {
    // Classic Spiral Nautilus-style Shell
    const shellGrad = ctx.createRadialGradient(-s * 0.2, 0, 0, -s * 0.2, 0, s);
    shellGrad.addColorStop(0, '#FFFBEB'); // Amber 50
    shellGrad.addColorStop(0.7, '#FCD34D'); // Amber 300
    shellGrad.addColorStop(1, '#92400E'); // Amber 800
    ctx.fillStyle = shellGrad;
    
    // Draw spiral segments
    for(let i = 5; i > 0; i--) {
      const radius = s * (i/5);
      const offX = -s * 0.2 + (5-i) * (s*0.1);
      ctx.beginPath();
      ctx.arc(offX, 0, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.1)';
      ctx.stroke();
    }
    
    // Shine
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    ctx.ellipse(-s * 0.4, -s * 0.3, s * 0.3, s * 0.15, -0.5, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Elongated Conch-style Shell
    const conchGrad = ctx.createLinearGradient(-s * 1.8, 0, s * 0.8, 0);
    conchGrad.addColorStop(0, '#FDF2F8'); // Pink 50
    conchGrad.addColorStop(0.5, '#F9A8D4'); // Pink 300
    conchGrad.addColorStop(1, '#BE185D'); // Pink 700
    ctx.fillStyle = conchGrad;
    
    ctx.beginPath();
    ctx.moveTo(-s * 1.8, s * 0.3);
    ctx.lineTo(-s * 1.2, -s * 0.7);
    ctx.quadraticCurveTo(-s * 0.5, -s * 0.9, s * 0.2, -s * 0.2);
    ctx.lineTo(s * 0.8, s * 0.3);
    ctx.closePath();
    ctx.fill();
    
    // Texture lines for the conch
    ctx.strokeStyle = 'rgba(0,0,0,0.15)';
    ctx.lineWidth = 1;
    for(let i = 0; i < 4; i++) {
      const tx = -s * 1.5 + i * (s * 0.4);
      ctx.beginPath();
      ctx.moveTo(tx, s * 0.3);
      ctx.lineTo(tx + s * 0.2, -s * 0.5);
      ctx.stroke();
    }
  }

  ctx.restore();
}

export function drawRock(ctx: CanvasRenderingContext2D, s: number) {
  // Textured Rock Base - More realistic, irregular and weathered
  ctx.save();
  const grad = ctx.createLinearGradient(0, -s, 0, s);
  grad.addColorStop(0, '#64748B'); // Slate 400
  grad.addColorStop(1, '#1E293B'); // Slate 800
  ctx.fillStyle = grad;
  
  ctx.beginPath();
  ctx.moveTo(-s, s * 0.4);
  ctx.quadraticCurveTo(-s * 1.2, -s * 0.2, -s * 0.6, -s * 0.8);
  ctx.quadraticCurveTo(0, -s * 1.2, s * 0.7, -s * 0.8);
  ctx.quadraticCurveTo(s * 1.2, -s * 0.2, s, s * 0.4);
  ctx.closePath();
  ctx.fill();

  // Weathered/Porous texture details
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  for(let i = 0; i < 8; i++) {
    const px = Math.cos(i) * s * 0.6;
    const py = Math.sin(i * 1.5) * s * 0.5;
    ctx.beginPath();
    ctx.arc(px, py, s * 0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  // Branching Corals (Pink/Purple)
  ctx.strokeStyle = '#D946EF'; // Fuchsia 500
  ctx.lineWidth = s * 0.15;
  ctx.lineCap = 'round';
  const coralSeeds = [-0.6, 0.5];
  coralSeeds.forEach((seed, idx) => {
    const cx = s * seed;
    const cy = -s * 0.6;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + (idx === 0 ? -s * 0.4 : s * 0.4), cy - s * 0.6);
    ctx.moveTo(cx + (idx === 0 ? -s * 0.2 : s * 0.2), cy - s * 0.3);
    ctx.lineTo(cx + (idx === 0 ? s * 0.2 : -s * 0.2), cy - s * 0.5);
    ctx.stroke();
  });

  // Blue Textured Patches
  ctx.fillStyle = '#3B82F6'; // Blue 500
  for(let i = 0; i < 4; i++) {
    const bx = Math.sin(i * 2) * s * 0.4;
    const by = Math.cos(i * 3) * s * 0.3;
    ctx.beginPath();
    ctx.ellipse(bx, by, s * 0.25, s * 0.15, i, 0, Math.PI * 2);
    ctx.fill();
  }

  // Bright Orange Sea Sponges/Corals
  ctx.fillStyle = '#F97316'; // Orange 500
  const sx = s * 0.3;
  const sy = -s * 0.4;
  ctx.beginPath();
  ctx.arc(sx, sy, s * 0.3, 0, Math.PI * 2);
  ctx.fill();
  
  // Sponge holes
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  for(let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(sx + Math.cos(i*2) * s * 0.15, sy + Math.sin(i*2) * s * 0.15, s * 0.05, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

export function drawSharpBasalt(ctx: CanvasRenderingContext2D, s: number) {
  ctx.save();
  // Textured Sharp Basalt - Multi-faceted and weathered
  const grad = ctx.createLinearGradient(0, -s, 0, s);
  grad.addColorStop(0, '#334155');
  grad.addColorStop(1, '#0f172a');
  ctx.fillStyle = grad;
  
  ctx.beginPath();
  ctx.moveTo(-s, s * 0.5); 
  ctx.lineTo(-s * 1.2, 0); 
  ctx.lineTo(-s * 0.5, -s * 0.8); 
  ctx.lineTo(0, -s); 
  ctx.lineTo(s * 0.5, -s * 0.8); 
  ctx.lineTo(s * 1.2, 0); 
  ctx.lineTo(s, s * 0.5); 
  ctx.closePath(); 
  ctx.fill();

  // Texture details (pits and facets)
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  for(let i = 0; i < 6; i++) {
    const px = Math.sin(i * 1.2) * s * 0.5;
    const py = Math.cos(i * 0.8) * s * 0.4;
    ctx.beginPath();
    ctx.arc(px, py, s * 0.08, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Facet highlights
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-s * 0.5, -s * 0.8); ctx.lineTo(0, 0); ctx.lineTo(s * 0.5, -s * 0.8);
  ctx.stroke();

  ctx.restore();
}

export function drawRiverPebbles(ctx: CanvasRenderingContext2D, s: number) {
  const baseColors = ['#bfdbfe', '#e9d5ff', '#d1fae5'];
  const darkColors = ['#60a5fa', '#a855f7', '#10b981'];
  
  for (let i = 0; i < 3; i++) {
    ctx.save();
    const px = i * s * 0.6 - s * 0.6;
    const py = s * 0.2;
    const pr = s * 0.45;

    // Realistic Smooth Pebble Gradient
    const grad = ctx.createRadialGradient(px - pr * 0.3, py - pr * 0.3, 0, px, py, pr);
    grad.addColorStop(0, baseColors[i]);
    grad.addColorStop(1, darkColors[i]);
    ctx.fillStyle = grad;
    
    ctx.beginPath(); 
    ctx.arc(px, py, pr, 0, Math.PI * 2); 
    ctx.fill();
    
    // Texture/Highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.beginPath();
    ctx.ellipse(px - pr * 0.2, py - pr * 0.2, pr * 0.3, pr * 0.15, -0.7, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }
}

export function drawCrystalRock(ctx: CanvasRenderingContext2D, s: number, time: number) {
  // Textured Rock Base for Crystal
  ctx.save();
  const grad = ctx.createLinearGradient(0, -s, 0, s);
  grad.addColorStop(0, '#475569');
  grad.addColorStop(1, '#1e293b');
  ctx.fillStyle = grad;
  
  ctx.beginPath(); 
  ctx.arc(0, 0, s, 0, Math.PI * 2); 
  ctx.fill();
  
  // Weathered pits on the base
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  for(let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.arc(Math.cos(i) * s * 0.6, Math.sin(i) * s * 0.6, s * 0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  // Crystal Growth
  const pulse = 0.5 + Math.sin(time * 0.005) * 0.5;
  ctx.fillStyle = `rgba(129, 140, 248, ${0.4 + pulse * 0.4})`;
  ctx.shadowBlur = 15 * pulse;
  ctx.shadowColor = '#818CF8';
  ctx.beginPath(); 
  ctx.moveTo(0, -s * 1.2); 
  ctx.lineTo(s * 0.4, 0); 
  ctx.lineTo(-s * 0.4, 0); 
  ctx.closePath(); 
  ctx.fill();
  
  ctx.shadowBlur = 0;
  ctx.restore();
}

export function drawCoralBush(ctx: CanvasRenderingContext2D, s: number, time: number) {
  ctx.strokeStyle = '#F472B6';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  for (let i = 0; i < 5; i++) {
    const angle = (i / 5) * Math.PI - Math.PI / 2;
    const sway = Math.sin(time * 0.003 + i) * 5;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(angle) * s + sway, Math.sin(angle) * s); ctx.stroke();
  }
}

export function drawBulbousSeaShrub(ctx: CanvasRenderingContext2D, s: number, time: number) {
  ctx.fillStyle = '#0D9488';
  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2;
    const x = Math.cos(angle) * s * 0.6;
    const y = Math.sin(angle) * s * 0.6 - s * 0.5;
    ctx.beginPath(); ctx.arc(x, y, s * 0.4, 0, Math.PI * 2); ctx.fill();
  }
}

export function drawFernLikeSeaFrond(ctx: CanvasRenderingContext2D, s: number, time: number) {
  ctx.strokeStyle = '#10B981';
  ctx.lineWidth = 2;
  const sway = Math.sin(time * 0.003) * 0.2;
  ctx.save(); ctx.rotate(sway);
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -s * 1.5); ctx.stroke();
  for (let i = 0; i < 6; i++) {
    const h = -i * s * 0.2;
    ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(s * 0.5, h - 5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(-s * 0.5, h - 5); ctx.stroke();
  }
  ctx.restore();
}

export function drawGlowingAnemoneShrub(ctx: CanvasRenderingContext2D, s: number, time: number) {
  const pulse = 0.6 + Math.sin(time * 0.01) * 0.4;
  ctx.strokeStyle = '#D946EF';
  ctx.lineWidth = 3;
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const tx = Math.cos(angle) * s;
    const ty = Math.sin(angle) * s;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(tx, ty); ctx.stroke();
    ctx.fillStyle = `rgba(255, 255, 255, ${pulse})`;
    ctx.shadowBlur = 10 * pulse; ctx.shadowColor = '#D946EF';
    ctx.beginPath(); ctx.arc(tx, ty, 3, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
  }
}

export function drawAmbientCreature(ctx: CanvasRenderingContext2D, creature: any, time: number) {
  ctx.save();
  ctx.translate(creature.x, creature.y);
  ctx.scale(creature.direction || 1, 1);
  const s = creature.size || 18;
  switch (creature.type) {
    case 'turtle':
      const swim = Math.sin(time * 0.005) * 0.3;
      ctx.fillStyle = '#1A7431';
      ctx.save(); ctx.translate(s*0.3, s*0.3); ctx.rotate(swim); ctx.beginPath(); ctx.ellipse(0,0, s*0.7, s*0.3, 0.3, 0, Math.PI*2); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(-s*0.3, s*0.3); ctx.rotate(-swim); ctx.beginPath(); ctx.ellipse(0,0, s*0.6, s*0.25, -0.3, 0, Math.PI*2); ctx.fill(); ctx.restore();
      ctx.fillStyle = '#55A630'; ctx.beginPath(); ctx.moveTo(-s*1.2, s*0.2); ctx.bezierCurveTo(-s*1.2, -s*1.1, s*0.9, -s*1.1, s*0.9, s*0.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#1A7431'; ctx.beginPath(); ctx.ellipse(s*1.2, -s*0.1, s*0.4, s*0.3, 0.2, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = 'black'; ctx.beginPath(); ctx.arc(s*1.4, -s*0.2, 2, 0, Math.PI*2); ctx.fill();
      break;
    case 'snail': case 'snail_2': drawSnail(ctx, creature.type, time, s); break;
    case 'rock': drawRock(ctx, s); break;
    case 'sharp_basalt': drawSharpBasalt(ctx, s); break;
    case 'river_pebbles': drawRiverPebbles(ctx, s); break;
    case 'crystal_rock': drawCrystalRock(ctx, s, time); break;
    case 'coral_bush': drawCoralBush(ctx, s, time); break;
    case 'bulbous_shrub': drawBulbousSeaShrub(ctx, s, time); break;
    case 'fern_frond': drawFernLikeSeaFrond(ctx, s, time); break;
    case 'anemone_shrub': drawGlowingAnemoneShrub(ctx, s, time); break;
    case 'tall_kelp': drawTallKelp(ctx, 0, 0, time, creature.x); break;
    case 'carpet_grass': drawShortCarpetGrass(ctx, 0, 0, time, creature.x); break;
    case 'ribbon_grass': drawCurlyRibbonGrass(ctx, 0, 0, time, creature.x); break;
  }
  ctx.restore();
}

export function drawPlayer(ctx: CanvasRenderingContext2D, player: any) {
  const time = Date.now();
  const colors = SKIN_DATA[player.skin] || SKIN_DATA.fish_1;
  const skinInfo = INITIAL_SKINS.find(s => s.id === player.skin);
  const s = player.radius || 18;
  const speed = Math.hypot(player.vx, player.vy);
  const isMoving = speed > 0.5;
  
  // Base idle sway for tail/fins to look alive even when stopping
  const idleWiggle = Math.sin(time * 0.003) * 0.15;
  const effectiveSpeed = isMoving ? speed : idleWiggle;
  
  ctx.save();
  ctx.translate(player.x, player.y);
  
  // Magnet active effect
  if (player.magnetTimer > 0) {
    const pulse = 0.5 + Math.sin(time * 0.01) * 0.5;
    ctx.strokeStyle = `rgba(59, 130, 246, ${pulse * 0.6})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, s * (1.5 + pulse * 0.5), 0, Math.PI * 2);
    ctx.stroke();
  }

  // Shield active effect (Glowing Heart Protection)
  if (player.hasShield) {
    const pulse = 0.5 + Math.sin(time * 0.01) * 0.5;
    ctx.strokeStyle = `rgba(244, 63, 94, ${0.4 + pulse * 0.4})`;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, s * 1.8, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner faint glow
    ctx.fillStyle = `rgba(244, 63, 94, ${0.1 + pulse * 0.1})`;
    ctx.fill();
  }
  
  // Orientation
  ctx.rotate(player.angle);
  const isFacingLeft = Math.cos(player.angle) < 0;
  if (isFacingLeft) ctx.scale(1, -1);
  
  if (player.isCelebrating) ctx.rotate(player.celebrationAngle);
  
  // Body and Fins based on Archetype
  drawFishBody(ctx, s, colors, skinInfo?.shape || 'standard', time, isMoving, effectiveSpeed);
  
  ctx.restore();
}

export function drawSchoolFish(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, skinId: string, angle: number, time: number) {
  const colors = SKIN_DATA[skinId] || SKIN_DATA.fish_1;
  const skinInfo = INITIAL_SKINS.find(s => s.id === skinId);
  
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  const isFacingLeft = Math.cos(angle) < 0;
  if (isFacingLeft) ctx.scale(1, -1);
  
  drawFishBody(ctx, s, colors, skinInfo?.shape || 'standard', time, true, 2);
  
  ctx.restore();
}

export function drawBubble(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, life: number) {
  ctx.save(); ctx.globalAlpha = life * 0.5; ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, size, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)'; ctx.beginPath(); ctx.arc(x - size * 0.3, y - size * 0.3, size * 0.2, 0, Math.PI * 2); ctx.fill(); ctx.restore();
}

export function drawFinishFeast(ctx: CanvasRenderingContext2D, pos: { x: number, y: number }, time: number, level: number) {
  const r = 45;
  const hueMap = [190, 120, 280, 45];
  const targetHue = hueMap[(level - 1) % 4];
  
  ctx.save();
  ctx.translate(pos.x, pos.y);
  
  const burstPulse = 1 + Math.sin(time * 0.002) * 0.15;
  
  // Massive Light Burst Aura
  const glows = [ 
    { radius: r * 10, alpha: 0.1, stop: 1 }, 
    { radius: r * 6, alpha: 0.2, stop: 0.6 }, 
    { radius: r * 3, alpha: 0.35, stop: 0.3 } 
  ];
  
  glows.forEach(g => {
    const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, g.radius * burstPulse);
    grad.addColorStop(0, `hsla(${targetHue}, 100%, 90%, ${g.alpha * 2})`); 
    grad.addColorStop(0.3, `hsla(${targetHue}, 100%, 75%, ${g.alpha})`); 
    grad.addColorStop(g.stop, 'transparent');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, g.radius * burstPulse, 0, Math.PI * 2);
    ctx.fill();
  });
  
  // Rotating Rays
  ctx.save();
  ctx.rotate(time * 0.0004);
  for (let i = 0; i < 20; i++) {
    const angle = (i / 20) * Math.PI * 2;
    const rayLength = r * (8 + Math.sin(time * 0.002 + i) * 2);
    const rayWidth = i % 2 === 0 ? 12 : 6;
    const rayGrad = ctx.createLinearGradient(r * 0.5, 0, rayLength, 0);
    rayGrad.addColorStop(0, `hsla(${targetHue}, 100%, 95%, 0.9)`); 
    rayGrad.addColorStop(1, 'transparent');
    ctx.save();
    ctx.rotate(angle);
    ctx.fillStyle = rayGrad;
    ctx.beginPath();
    ctx.moveTo(r * 0.5, -rayWidth);
    ctx.lineTo(rayLength, 0);
    ctx.lineTo(r * 0.5, rayWidth);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Oyster Shell Anatomy (Correct Bivalve Structure)
  const shellW = r * 2.2;
  const shellH = r * 1.0;

  // 1. Bottom Shell (Base sitting on seafloor)
  const baseGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, shellW);
  baseGrad.addColorStop(0, '#ffffff'); // Nacre center
  baseGrad.addColorStop(0.7, '#e0f2fe'); // Soft blue interior
  baseGrad.addColorStop(1, '#bae6fd'); // Blue outer edge
  
  ctx.fillStyle = baseGrad;
  ctx.strokeStyle = '#D4AF37'; // Golden border
  ctx.lineWidth = 4;
  
  ctx.beginPath();
  ctx.ellipse(0, shellH * 0.3, shellW, shellH * 0.7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // 2. The Luminous Pearl (Perfectly Centered in lower shell)
  const pr = r * 0.85 * (1 + Math.sin(time * 0.003) * 0.05);
  const pearlGrad = ctx.createRadialGradient(-pr * 0.3, -pr * 0.3, 0, 0, 0, pr);
  pearlGrad.addColorStop(0, '#ffffff'); 
  pearlGrad.addColorStop(0.4, `hsla(${targetHue}, 90%, 60%, 1)`); 
  pearlGrad.addColorStop(1, `hsla(${targetHue}, 100%, 25%, 1)`);
  
  ctx.shadowBlur = 40 * burstPulse; 
  ctx.shadowColor = `hsla(${targetHue}, 100%, 75%, 1)`; 
  ctx.fillStyle = pearlGrad; 
  ctx.beginPath(); 
  ctx.arc(0, shellH * 0.2, pr, 0, Math.PI * 2); 
  ctx.fill(); 
  ctx.shadowBlur = 0;
  
  // Pearl Highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.beginPath();
  ctx.ellipse(-pr * 0.4, shellH * 0.2 - pr * 0.4, pr * 0.4, pr * 0.2, -Math.PI / 4, 0, Math.PI * 2);
  ctx.fill();

  // 3. Top Shell (Lid open upwards)
  ctx.save();
  const openOffset = -shellH * 0.5;
  const tilt = -0.8 + Math.sin(time * 0.001) * 0.05;
  ctx.translate(0, openOffset);
  ctx.rotate(tilt);
  
  // Top shell interior (usually lighter)
  const lidGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, shellW);
  lidGrad.addColorStop(0, '#ffffff');
  lidGrad.addColorStop(0.8, '#f8fafc');
  lidGrad.addColorStop(1, '#e2e8f0');
  
  ctx.fillStyle = lidGrad;
  ctx.strokeStyle = '#B45309'; // Darker gold border for contrast
  ctx.lineWidth = 4;
  
  ctx.beginPath();
  ctx.ellipse(0, 0, shellW, shellH * 0.7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Texture lines on lid
  ctx.strokeStyle = 'rgba(0,0,0,0.05)';
  ctx.lineWidth = 2;
  for(let i = -3; i <= 3; i++) {
    ctx.beginPath();
    ctx.moveTo(i * shellW * 0.25, -shellH * 0.6);
    ctx.lineTo(i * shellW * 0.1, shellH * 0.6);
    ctx.stroke();
  }
  
  ctx.restore();
  ctx.restore();
}

export function drawCoin(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number) {
  ctx.save();
  ctx.translate(x, y + Math.sin(time * 0.005) * 8);

  ctx.shadowBlur = 10;
  ctx.shadowColor = 'rgba(0,0,0,0.4)';
  ctx.shadowOffsetY = 4;

  const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, 0, 0, 0, r);
  grad.addColorStop(0, '#ffee58');
  grad.addColorStop(0.7, '#fbc02d');
  grad.addColorStop(1, '#f57f17');
  
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();

  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
  ctx.strokeStyle = '#e65100';
  ctx.lineWidth = r * 0.12;
  ctx.stroke();

  ctx.strokeStyle = 'rgba(160, 60, 0, 0.3)';
  ctx.lineWidth = 1;
  ctx.setLineDash([r * 0.2, r * 0.2]);
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.8, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
  ctx.beginPath();
  ctx.ellipse(-r * 0.4, -r * 0.4, r * 0.5, r * 0.25, -Math.PI / 4, 0, Math.PI * 2);
  ctx.fill();

  const f = r * 0.012; 
  ctx.save();
  ctx.translate(-r * 0.1, r * 0.1); 
  ctx.strokeStyle = '#5d4037';
  ctx.fillStyle = 'rgba(93, 64, 55, 0.15)';
  ctx.lineWidth = r * 0.08;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  ctx.moveTo(-15 * f, 15 * f);
  ctx.bezierCurveTo(-25 * f, -5 * f, -5 * f, -35 * f, 20 * f, -32 * f);
  ctx.bezierCurveTo(45 * f, -28 * f, 45 * f, 5 * f, 35 * f, 15 * f);
  ctx.bezierCurveTo(25 * f, 25 * f, 5 * f, 15 * f, -10 * f, 15 * f);
  ctx.closePath();
  ctx.stroke();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(5 * f, -28 * f);
  ctx.bezierCurveTo(8 * f, -45 * f, 20 * f, -45 * f, 25 * f, -30 * f);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(35 * f, 15 * f);
  ctx.bezierCurveTo(48 * f, 22 * f, 52 * f, 15 * f, 50 * f, 5 * f);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(35 * f, 15 * f);
  ctx.bezierCurveTo(40 * f, 30 * f, 30 * f, 35 * f, 25 * f, 30 * f);
  ctx.stroke();

  ctx.fillStyle = '#5d4037';
  ctx.beginPath();
  ctx.arc(-5 * f, 0, 2.5 * f, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
  ctx.restore();
}

export function drawMagnet(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number) {
  ctx.save();
  ctx.translate(x, y + Math.sin(time * 0.005) * 8);
  ctx.rotate(Math.sin(time * 0.004) * 0.3);

  // Horseshoe Magnet Shape
  const thick = r * 0.6;
  ctx.lineCap = 'round';
  
  // Outer U
  ctx.lineWidth = thick;
  
  // Red side (N)
  ctx.strokeStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(0, 0, r, Math.PI, Math.PI * 1.5);
  ctx.stroke();
  
  // Blue side (S)
  ctx.strokeStyle = '#3b82f6';
  ctx.beginPath();
  ctx.arc(0, 0, r, Math.PI * 1.5, Math.PI * 2);
  ctx.stroke();
  
  // Tips
  ctx.fillStyle = '#ddd';
  ctx.beginPath();
  ctx.arc(-r, 0, thick/2, 0, Math.PI*2);
  ctx.arc(r, 0, thick/2, 0, Math.PI*2);
  ctx.fill();

  ctx.restore();
}

export function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number) {
  ctx.save();
  ctx.translate(x, y + Math.sin(time * 0.005) * 8);
  const pulse = 0.9 + Math.sin(time * 0.01) * 0.15;
  ctx.scale(pulse, pulse);

  ctx.shadowBlur = 20;
  ctx.shadowColor = '#f43f5e';

  ctx.fillStyle = '#f43f5e';
  ctx.beginPath();
  const d = r * 1.4;
  ctx.moveTo(0, -d * 0.2);
  ctx.bezierCurveTo(0, -d * 0.6, -d * 0.7, -d * 0.6, -d * 0.7, -d * 0.2);
  ctx.bezierCurveTo(-d * 0.7, d * 0.2, 0, d * 0.6, 0, d * 0.9);
  ctx.bezierCurveTo(0, d * 0.6, d * 0.7, d * 0.2, d * 0.7, -d * 0.2);
  ctx.bezierCurveTo(d * 0.7, -d * 0.6, 0, -d * 0.6, 0, -d * 0.2);
  ctx.fill();
  
  // Inner Shine
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.beginPath();
  ctx.arc(-d * 0.25, -d * 0.25, d * 0.15, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.restore();
}

export function drawGrenade(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number) {
  const vr = r * 1.3;
  ctx.save(); 
  ctx.translate(x, y); 
  
  // Massive overall glow for high visibility (Double the original intensity)
  ctx.shadowBlur = 45 + Math.sin(time * 0.01) * 20; 
  ctx.shadowColor = 'rgba(255, 0, 0, 1)';
  
  // Vibrant Red Primary Color
  const bodyGrad = ctx.createRadialGradient(-vr*0.2, -vr*0.2, 0, 0, 0, vr);
  bodyGrad.addColorStop(0, '#ff4d4d'); // Bright red highlight
  bodyGrad.addColorStop(1, '#b30000'); // Deep vibrant red base
  ctx.fillStyle = bodyGrad; 
  ctx.beginPath(); 
  ctx.arc(0, 0, vr, 0, Math.PI * 2); 
  ctx.fill(); 
  
  ctx.shadowBlur = 0; 
  
  // Increased Brightness for Shine highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)'; 
  ctx.beginPath(); 
  ctx.ellipse(-vr*0.35, -vr*0.35, vr*0.5, vr*0.25, -0.7, 0, Math.PI * 2); 
  ctx.fill();
  
  // Longer Wick (Fuse)
  ctx.strokeStyle = '#92400E'; 
  ctx.lineWidth = 3.5; 
  ctx.beginPath(); 
  ctx.moveTo(0, -vr); 
  ctx.bezierCurveTo(vr * 0.5, -vr * 1.8, vr * 1.5, -vr * 1.5, vr * 1.1, -vr * 0.8);
  ctx.stroke();
  
  // Blazing Fire Animation Effect at the tip
  const fx = vr * 1.1;
  const fy = -vr * 0.8;
  const flamePulse = Math.sin(time * 0.02) * 0.3 + 1.2;
  const jitterX = Math.sin(time * 0.05) * 2;
  const jitterY = Math.cos(time * 0.07) * 2;
  
  ctx.save();
  ctx.translate(fx + jitterX, fy + jitterY);
  
  // Layered Blazing Flame
  ctx.shadowBlur = 25 * flamePulse;
  ctx.shadowColor = '#ff6600';
  ctx.fillStyle = 'rgba(255, 69, 0, 0.7)';
  ctx.beginPath();
  ctx.arc(0, 0, 8 * flamePulse, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.shadowBlur = 15 * flamePulse;
  ctx.shadowColor = '#ffcc00';
  ctx.fillStyle = 'rgba(255, 200, 0, 0.9)';
  ctx.beginPath();
  ctx.arc(0, 0, 5 * flamePulse, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.shadowBlur = 10;
  ctx.shadowColor = '#ffffff';
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, 0, 2 * flamePulse, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.restore();
  ctx.restore();
}

export function drawJellyfish(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number, hue?: number) {
  // Realistic vertical floating drift
  const verticalDrift = Math.sin(time * 0.0015) * 25;
  // Pulsing expansion/contraction rhythm
  const pulse = 1 + Math.sin(time * 0.004) * 0.08;
  const currentR = r * pulse;
  const targetHue = hue !== undefined ? hue : 260;

  ctx.save();
  ctx.translate(x, y + verticalDrift);
  
  // Outer Glow
  ctx.shadowBlur = 25;
  ctx.shadowColor = `hsla(${targetHue}, 70%, 70%, 0.6)`;
  
  // Translucent Dome with Vibrant Multi-colored Gradient
  const domeGrad = ctx.createRadialGradient(-currentR * 0.3, -currentR * 0.3, 0, 0, 0, currentR);
  domeGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
  domeGrad.addColorStop(0.5, `hsla(${targetHue}, 80%, 80%, 0.7)`);
  domeGrad.addColorStop(1, `hsla(${targetHue}, 60%, 60%, 0.5)`);
  
  ctx.fillStyle = domeGrad;
  ctx.beginPath();
  ctx.arc(0, 0, currentR, Math.PI, 0);
  ctx.fill();
  
  // Glossy Shine Highlight
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.beginPath();
  ctx.ellipse(-currentR * 0.4, -currentR * 0.4, currentR * 0.5, currentR * 0.15, -Math.PI / 4, 0, Math.PI * 2);
  ctx.fill();

  // Cute Cartoon Eyes
  const eyeOffset = currentR * 0.35;
  const eyeSize = currentR * 0.16;
  const pupilSize = currentR * 0.07;
  
  ctx.fillStyle = 'white';
  ctx.beginPath(); ctx.arc(-eyeOffset, -currentR * 0.3, eyeSize, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'black';
  ctx.beginPath(); ctx.arc(-eyeOffset + 2, -currentR * 0.3, pupilSize, 0, Math.PI * 2); ctx.fill();
  
  ctx.fillStyle = 'white';
  ctx.beginPath(); ctx.arc(eyeOffset, -currentR * 0.3, eyeSize, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'black';
  ctx.beginPath(); ctx.arc(eyeOffset + 2, -currentR * 0.3, pupilSize, 0, Math.PI * 2); ctx.fill();

  // Friendly Smile
  ctx.strokeStyle = `hsla(${targetHue}, 80%, 20%, 0.4)`;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(0, -currentR * 0.12, currentR * 0.15, 0.2 * Math.PI, 0.8 * Math.PI);
  ctx.stroke();

  // Refined Flowing Tentacles
  ctx.shadowBlur = 0; 
  
  for (let i = 0; i < 7; i++) {
    const startX = -currentR * 0.8 + (i * currentR * 0.28);
    const sway = Math.sin(time * 0.003 + i) * (15 * pulse);
    ctx.strokeStyle = `hsla(${targetHue}, 80%, 90%, ${0.45 - (i * 0.02)})`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(startX, 0);
    ctx.bezierCurveTo(startX + sway, currentR * 1.5, startX - sway, currentR * 2.5, startX, currentR * 3.5);
    ctx.stroke();
  }
  
  for (let i = 0; i < 4; i++) {
    const startX = -currentR * 0.5 + (i * currentR * 0.35);
    const ripple = Math.cos(time * 0.003 + i) * 12;
    ctx.strokeStyle = `hsla(${targetHue}, 70%, 75%, 0.55)`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(startX, 0);
    ctx.quadraticCurveTo(startX + ripple, currentR * 0.8, startX, currentR * 1.8);
    ctx.stroke();
  }

  ctx.restore();
}

export function drawDirectionIndicator(ctx: CanvasRenderingContext2D, player: any, target: { x: number, y: number }) {
  const dx = target.x - player.x; const dy = target.y - player.y;
  if (Math.hypot(dx, dy) < 50) return;
  ctx.save(); ctx.translate(player.x, player.y); ctx.rotate(Math.atan2(dy, dx)); ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)'; ctx.setLineDash([5, 5]); ctx.beginPath(); ctx.moveTo(40, 0); ctx.lineTo(100, 0); ctx.stroke(); ctx.restore();
}

export function drawMonsterFish(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, time: number) {
  const mouthOpen = Math.sin(time * 0.003) * 0.2 + 0.2; // slow mouth opening/closing
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(-1, 1); // Opposite direction (swimming right to left)

  // Aggressive Body Design
  const bodyGrad = ctx.createLinearGradient(0, -r, 0, r);
  bodyGrad.addColorStop(0, '#334155'); // Dark grey back
  bodyGrad.addColorStop(0.6, '#ef4444'); // Reddish belly
  ctx.fillStyle = bodyGrad;
  
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 1.5, r * 0.9, 0, 0, Math.PI * 2);
  ctx.fill();

  // Sharp Predator Teeth
  ctx.fillStyle = 'white';
  const teethY = mouthOpen * r * 0.8;
  for (let i = 0; i < 4; i++) {
    const tx = r * (0.8 + i * 0.15);
    ctx.beginPath();
    ctx.moveTo(tx, -teethY);
    ctx.lineTo(tx + 5, teethY);
    ctx.lineTo(tx - 5, teethY);
    ctx.closePath();
    ctx.fill();
  }

  // Angry Yellow Eyes
  ctx.fillStyle = '#facc15'; // Yellow
  ctx.beginPath();
  ctx.arc(r * 0.7, -r * 0.3, r * 0.25, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.fillStyle = 'black'; // Pupil
  ctx.beginPath();
  ctx.arc(r * 0.8, -r * 0.3, r * 0.12, 0, Math.PI * 2);
  ctx.fill();

  // Predator Fins
  ctx.fillStyle = '#1e293b';
  const finSway = Math.sin(time * 0.005) * 5;
  // Dorsal
  ctx.beginPath();
  ctx.moveTo(0, -r * 0.8);
  ctx.lineTo(-r * 0.6, -r * 1.5 + finSway);
  ctx.lineTo(r * 0.3, -r * 0.7);
  ctx.fill();
  
  // Tail
  ctx.beginPath();
  ctx.moveTo(-r * 1.5, 0);
  ctx.lineTo(-r * 2.2, -r + finSway);
  ctx.lineTo(-r * 2.2, r + finSway);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}
