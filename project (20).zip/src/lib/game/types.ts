'use client';

export type GameState = 'START' | 'PLAYING' | 'PAUSED' | 'GAME_OVER' | 'WIN' | 'CELEBRATING';
export type BiomeType = 'coral_lagoon' | 'deep_sea' | 'volcanic_reef' | 'arctic_glacier' | 'atlantis_ruins' | 'toxic_swamp';

export interface Vector {
  x: number;
  y: number;
}

export interface LevelData {
  id: number;
  name: string;
  theme: BiomeType;
  worldWidth: number;
  targetCherries: number;
  description: string;
  waterColors: [string, string, string];
  sandColor: string;
  sunrayColor: string;
  plantType: number;
  ambientFishColor: string;
  ambientCreatures: Array<{ type: string; x: number; y: number; vx: number; vy: number; size: number; direction: number; wobbleOffset: number }>;
  currents: Array<{ startX: number; startY: number; endX: number; endY: number; forceX: number; forceY: number }>;
  collectibles: Array<{ x: number; y: number; type: 'cherry' | 'coin' | 'heart' | 'grenade' | 'magnet'; radius: number; collected?: boolean }>;
  obstacles: Array<{ x: number; y: number; radius: number; type: string }>;
  fishSchools: Array<{ 
    x: number; 
    y: number; 
    vx: number; 
    fish: Array<{ dx: number; dy: number; sz: number; ph: number; skinId: string }> 
  }>;
}

export type FishSkinId = string;

export interface SkinColors {
  primary: string;
  secondary: string;
  accent: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Divine';
}

export interface FishSkin {
  id: string;
  name: string;
  price: number;
  unlocked: boolean;
  shape: string;
  colors: SkinColors;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Divine';
  aspectMultiplier: number;
  description: string;
}

export const SKIN_DATA: Record<string, SkinColors> = {
  fish_1: { primary: '#FF4500', secondary: '#FFFFFF', accent: '#000000', rarity: 'Common' },
  fish_2: { primary: '#FFA500', secondary: '#FFFFFF', accent: '#FFD700', rarity: 'Common' },
  fish_3: { primary: '#00FFFF', secondary: '#FF1493', accent: '#FFFFFF', rarity: 'Common' },
  fish_4: { primary: '#0000FF', secondary: '#FFFF00', accent: '#000000', rarity: 'Common' },
  fish_5: { primary: '#C0C0C0', secondary: '#00FFFF', accent: '#FF0000', rarity: 'Common' },
  fish_6: { primary: '#EAB308', secondary: '#3B82F6', accent: '#FFFFFF', rarity: 'Rare' },
  fish_7: { primary: '#008080', secondary: '#FF69B4', accent: '#FFFFFF', rarity: 'Rare' },
  fish_8: { primary: '#DC143C', secondary: '#800080', accent: '#FFFFFF', rarity: 'Rare' },
  fish_9: { primary: '#4682B4', secondary: '#FFFFFF', accent: '#000000', rarity: 'Common' },
  fish_10: { primary: '#2E8B57', secondary: '#DAA520', accent: '#000000', rarity: 'Rare' },
  fish_11: { primary: '#64748B', secondary: '#F1F5F9', accent: '#000000', rarity: 'Common' },
  fish_12: { primary: '#1E293B', secondary: '#F8FAFC', accent: '#38BDF8', rarity: 'Rare' },
  fish_13: { primary: '#B91C1C', secondary: '#FFFFFF', accent: '#000000', rarity: 'Rare' },
  fish_14: { primary: '#A5F3FC', secondary: '#D8B4FE', accent: '#FFFFFF', rarity: 'Common' },
  fish_15: { primary: '#166534', secondary: '#78350F', accent: '#BEF264', rarity: 'Rare' },
  fish_16: { primary: '#F59E0B', secondary: '#FEF3C7', accent: '#000000', rarity: 'Rare' },
  fish_17: { primary: '#0F172A', secondary: '#22D3EE', accent: '#FFFFFF', rarity: 'Common' },
  fish_18: { primary: '#7F1D1D', secondary: '#FEF2F2', accent: '#000000', rarity: 'Common' },
  fish_19: { primary: '#475569', secondary: '#94A3B8', accent: '#000000', rarity: 'Common' },
  fish_20: { primary: '#CBD5E1', secondary: '#FFFFFF', accent: '#1E293B', rarity: 'Common' },
  fish_21: { primary: '#18181B', secondary: '#FDE047', accent: '#EF4444', rarity: 'Epic' },
  fish_22: { primary: '#71717A', secondary: '#E4E4E7', accent: '#000000', rarity: 'Rare' },
  fish_23: { primary: '#0EA5E9', secondary: '#FFFFFF', accent: '#000000', rarity: 'Rare' },
  fish_24: { primary: '#FFF7ED', secondary: '#9A3412', accent: '#000000', rarity: 'Rare' },
  fish_25: { primary: '#422006', secondary: '#FEF08A', accent: '#000000', rarity: 'Rare' },
  fish_26: { primary: '#15803D', secondary: '#BEF264', accent: '#000000', rarity: 'Rare' },
  fish_27: { primary: '#DB2777', secondary: '#FDF2F8', accent: '#FDE047', rarity: 'Rare' },
  fish_28: { primary: '#FFFFFF', secondary: '#EA580C', accent: '#000000', rarity: 'Rare' },
  fish_29: { primary: '#E0F2FE', secondary: '#FFFFFF', accent: '#0284C7', rarity: 'Rare' },
  fish_30: { primary: '#A16207', secondary: '#FEF9C3', accent: '#000000', rarity: 'Epic' },
  fish_31: { primary: '#334155', secondary: '#FFFFFF', accent: '#B91C1C', rarity: 'Legendary' },
  fish_32: { primary: '#1D4ED8', secondary: '#93C5FD', accent: '#FFFFFF', rarity: 'Legendary' },
  fish_33: { primary: '#475569', secondary: '#CBD5E1', accent: '#1E293B', rarity: 'Rare' },
  fish_34: { primary: '#111827', secondary: '#22D3EE', accent: '#FFFFFF', rarity: 'Epic' },
  fish_35: { primary: '#D946EF', secondary: '#F5D3F8', accent: '#701A75', rarity: 'Epic' },
  fish_36: { primary: '#2563EB', secondary: '#93C5FD', accent: '#1E3A8A', rarity: 'Rare' },
  fish_37: { primary: '#3F3F46', secondary: '#71717A', accent: '#18181B', rarity: 'Rare' },
  fish_38: { primary: '#111827', secondary: '#EF4444', accent: '#FFFFFF', rarity: 'Rare' },
  fish_39: { primary: '#BE123C', secondary: '#FDA4AF', accent: '#FDE047', rarity: 'Rare' },
  fish_40: { primary: '#FF006E', secondary: '#3A86FF', accent: '#8338EC', rarity: 'Rare' },
  fish_41: { primary: '#18181B', secondary: '#3F3F46', accent: '#EF4444', rarity: 'Legendary' },
  fish_42: { primary: '#422006', secondary: '#A16207', accent: '#78350F', rarity: 'Legendary' },
  fish_43: { primary: '#0F172A', secondary: '#22D3EE', accent: '#F43F5E', rarity: 'Epic' },
  fish_44: { primary: '#1E293B', secondary: '#5EEAD4', accent: '#0D9488', rarity: 'Epic' },
  fish_45: { primary: '#082F49', secondary: '#FFFFFF', accent: '#0EA5E9', rarity: 'Legendary' },
  fish_46: { primary: '#991B1B', secondary: '#EF4444', accent: '#FDE047', rarity: 'Rare' },
  fish_47: { primary: '#1E1B4B', secondary: '#818CF8', accent: '#4338CA', rarity: 'Epic' },
  fish_48: { primary: '#0F766E', secondary: '#2DD4BF', accent: '#FEF08A', rarity: 'Epic' },
  fish_49: { primary: '#0F172A', secondary: '#FFFFFF', accent: '#2563EB', rarity: 'Legendary' },
  fish_50: { primary: '#FACC15', secondary: '#FFFFFF', accent: '#0EA5E9', rarity: 'Divine' },
  fish_51: { primary: '#00008B', secondary: '#FFFF00', accent: '#FFFFFF', rarity: 'Rare' },
  fish_52: { primary: '#00BFFF', secondary: '#FF8C00', accent: '#00FA9A', rarity: 'Epic' },
  fish_53: { primary: '#FFFFFF', secondary: '#000000', accent: '#FFFF00', rarity: 'Rare' },
  fish_54: { primary: '#FFFFFF', secondary: '#808080', accent: '#FFFF00', rarity: 'Rare' },
  fish_55: { primary: '#4682B4', secondary: '#C0C0C0', accent: '#FFFF00', rarity: 'Epic' },
  fish_56: { primary: '#696969', secondary: '#F5F5F5', accent: '#000000', rarity: 'Epic' },
  fish_57: { primary: '#FFC0CB', secondary: '#D3D3D3', accent: '#000000', rarity: 'Rare' },
  fish_58: { primary: '#FFFFFF', secondary: '#FF4500', accent: '#FFFF00', rarity: 'Rare' },
  fish_59: { primary: '#00008B', secondary: '#C0C0C0', accent: '#FFFFFF', rarity: 'Legendary' },
  fish_60: { primary: '#FFFF00', secondary: '#FFFFFF', accent: '#000000', rarity: 'Common' },
  fish_61: { primary: '#FFB6C1', secondary: '#808080', accent: '#000000', rarity: 'Epic' },
  fish_62: { primary: '#4B2C20', secondary: '#00FF00', accent: '#FFFFFF', rarity: 'Epic' },
  fish_63: { primary: '#800080', secondary: '#FF00FF', accent: '#FFFFFF', rarity: 'Epic' },
  fish_64: { primary: '#40E0D0', secondary: '#9370DB', accent: '#FFFFFF', rarity: 'Rare' },
  fish_65: { primary: '#8B4513', secondary: '#006400', accent: '#000000', rarity: 'Rare' },
  fish_66: { primary: '#DAA520', secondary: '#0000FF', accent: '#000000', rarity: 'Epic' },
  fish_67: { primary: '#0000FF', secondary: '#FFFF00', accent: '#FFFFFF', rarity: 'Rare' },
  fish_68: { primary: '#C0C0C0', secondary: '#FF0000', accent: '#FFFFFF', rarity: 'Legendary' },
  fish_69: { primary: '#000000', secondary: '#FF0000', accent: '#00FFFF', rarity: 'Legendary' },
  fish_70: { primary: '#FFFFFF', secondary: '#FFD700', accent: '#DC143C', rarity: 'Divine' },
  fish_71: { primary: '#0c0a22', secondary: '#6366f1', accent: '#a5b4fc', rarity: 'Epic' },
  fish_72: { primary: '#0f172a', secondary: '#8b5cf6', accent: '#c084fc', rarity: 'Legendary' },
  fish_73: { primary: '#f0f9ff', secondary: '#2dd4bf', accent: '#d946ef', rarity: 'Epic' },
  fish_74: { primary: '#1e293b', secondary: '#facc15', accent: '#3b82f6', rarity: 'Legendary' },
  fish_75: { primary: '#ffffff', secondary: '#fbbf24', accent: '#06b6d4', rarity: 'Divine' },
};

const speciesProfiles: Array<{ name: string; shape: string; aspect: number; description: string }> = [
  { name: "Ocellaris Clownfish", shape: "clownfish", aspect: 1.1, description: "Recognizable orange body with three white bands." },
  { name: "Fantail Goldfish", shape: "goldfish", aspect: 1.0, description: "Rounded deep body with a majestic double fan tail." },
  { name: "Neon Guppy", shape: "guppy", aspect: 1.3, description: "Small slim body with a large, colorful fan tail." },
  { name: "Royal Blue Tang", shape: "tang", aspect: 1.2, description: "Compressed royal blue body with a bright yellow tail." },
  { name: "Neon Tetra", shape: "tetra", aspect: 1.4, description: "Small slender body with brilliant neon blue and red stripes." },
  { name: "Royal Angelfish", shape: "angelfish", aspect: 1.5, description: "Tall vertically compressed body with long fins." },
  { name: "Red Turquoise Discus", shape: "discus", aspect: 1.0, description: "Perfectly round compressed body like a colorful disc." },
  { name: "Siamese Fighting Betta", shape: "betta", aspect: 1.1, description: "Small body with enormous flowing caudal and anal fins." },
  { name: "Broadbill Swordfish", shape: "swordfish", aspect: 1.8, description: "Streamlined body with a very long pointed bill." },
  { name: "Leafy Sea Dragon", shape: "seadragon", aspect: 1.6, description: "Thin elongated body with numerous leaf-like appendages." },
  { name: "Great Hammerhead Shark", shape: "hammerhead", aspect: 1.6, description: "Unmistakable wide hammer-shaped head with eyes at the ends." },
  { name: "Giant Oceanic Manta", shape: "manta", aspect: 1.0, description: "Enormous wing-shaped body with graceful swimming motion." },
  { name: "Red Lionfish", shape: "lionfish", aspect: 1.2, description: "Compact body with dramatic fan-like dorsal spines." },
  { name: "Moon Jellyfish", shape: "jellyfish", aspect: 1.0, description: "Translucent dome-shaped bell with multiple flowing tentacles." },
  { name: "Green Sea Turtle", shape: "turtle", aspect: 1.1, description: "Oval patterned shell with four powerful flippers." },
  { name: "Pacific Seahorse", shape: "seahorse", aspect: 0.8, description: "Upright posture with a horse-like head and curled tail." },
  { name: "Electric Eel", shape: "eel", aspect: 2.0, description: "Long snake-like body with glowing cyan electric bands." },
  { name: "Colossal Squid", shape: "squid", aspect: 1.5, description: "Large mantle with eight arms and two long feeding tentacles." },
  { name: "Smalltooth Sawfish", shape: "sawfish", aspect: 2.0, description: "Flattened body with a long tooth-like saw rostrum." },
  { name: "Arctic Narwhal", shape: "narwhal", aspect: 1.8, description: "Whale-like body featuring a single extremely long tusk." },
  { name: "Deepsea Anglerfish", shape: "anglerfish", aspect: 1.1, description: "Gigantic mouth with sharp teeth and a glowing lure." },
  { name: "Ocean Sunfish (Mola)", shape: "mola", aspect: 0.9, description: "Massive vertical disk-shaped body with tiny fins." },
  { name: "Atlantic Flying Fish", shape: "flyingFish", aspect: 1.4, description: "Streamlined body with huge wing-like pectoral fins." },
  { name: "Chambered Nautilus", shape: "nautilus", aspect: 1.0, description: "Ancient cephalopod with a visible spiral patterned shell." },
  { name: "Spotted Moray Eel", shape: "morayEel", aspect: 2.2, description: "Long snake-like body with spotted patterns and large head." },
  { name: "Weedy Seadragon", shape: "weedySeadragon", aspect: 1.7, description: "Narrow body with appendages resembling seaweed." },
  { name: "Flamboyant Cuttlefish", shape: "cuttlefish", aspect: 1.3, description: "Oval mantle with colorful bands and shimmer animation." },
  { name: "Japanese Nishikigoi", shape: "koi", aspect: 1.3, description: "Robust carp-like body with vibrant ornamental patches." },
  { name: "Antarctic Icefish", shape: "icefish", aspect: 1.5, description: "Pale translucent body adapted for freezing cold waters." },
  { name: "Porcupine Pufferfish", shape: "pufferfish", aspect: 1.0, description: "Spherical body covered in numerous short visible spines." },
  { name: "Great White Shark", shape: "greatWhite", aspect: 1.6, description: "Powerful predator with triangular dorsal and powerful tail." },
  { name: "Blue Whale Calf", shape: "whale", aspect: 1.8, description: "Huge rounded body with broad pectoral fins and tail flukes." },
  { name: "Great Barracuda", shape: "barracuda", aspect: 1.9, description: "Extremely long body with sharp teeth and silver coloration." },
  { name: "Flashlight Lanternfish", shape: "lanternfish", aspect: 1.3, description: "Deep-sea fish with glowing photophores along its underside." },
  { name: "Dumbo Octopus", shape: "dumboOctopus", aspect: 1.1, description: "Soft rounded mantle with two large ear-like fins." },
  { name: "Atlantic Sailfish", shape: "sailfish", aspect: 1.8, description: "Streamlined body with a very long pointed bill." },
  { name: "Living Fossil Coelacanth", shape: "coelacanth", aspect: 1.4, description: "Ancient lobed-finned fish with armored scale texture." },
  { name: "Pacific Viperfish", shape: "viperfish", aspect: 1.8, description: "Abyssal predator with thin body and massive fangs." },
  { name: "Hydrothermal Vent Fish", shape: "ventFish", aspect: 1.2, description: "Dark rugged body with red markings and cyan accents." },
  { name: "Rainbow Surge Wrasse", shape: "wrasse", aspect: 1.4, description: "Elongated colorful body with layered rainbow stripes." },
  { name: "Apex Megalodon", shape: "megalodon", aspect: 1.7, description: "Massive prehistoric shark with intimidating jaws and teeth." },
  { name: "Armored Dunkleosteus", shape: "dunkleosteus", aspect: 1.6, description: "Prehistoric fish with a heavily plated armored head." },
  { name: "Bioluminescent Leviathan", shape: "leviathan", aspect: 2.0, description: "Legendary abyssal creature with glowing cyan accents." },
  { name: "Abyssal Dragon Wyrm", shape: "dragonWyrm", aspect: 2.2, description: "Serpentine dragon with glowing markings and horns." },
  { name: "Titan Whale Shark", shape: "whaleShark", aspect: 1.8, description: "Massive filter feeder with distinctive spotted patterns." },
  { name: "Crimson Stingray", shape: "stingray", aspect: 1.1, description: "Wide flattened diamond body with crimson upper surface." },
  { name: "Eldritch Kraken", shape: "kraken", aspect: 1.4, description: "Legendary cephalopod with independent tentacle motion." },
  { name: "Electric Torpedo Ray", shape: "electricRay", aspect: 1.1, description: "Broad rounded ray body with pulsing electric rings." },
  { name: "Apex Phantom Orca", shape: "orca", aspect: 1.7, description: "Powerful silhouette immediately recognizable as an orca." },
  { name: "Infinity Sovereign Godfish", shape: "sovereignFish", aspect: 1.6, description: "Divine celestial creature with majestic flowing fins." },
  { name: "Emperor Angelfish", shape: "emperorAngelfish", aspect: 1.2, description: "Deep royal-blue body with bright yellow horizontal stripes." },
  { name: "Mandarinfish", shape: "mandarinFish", aspect: 1.1, description: "Small body with intricate colorful markings and rounded fins." },
  { name: "Moorish Idol", shape: "moorishIdol", aspect: 1.4, description: "Thin vertically compressed body with an extremely long dorsal filament." },
  { name: "Clown Triggerfish", shape: "triggerfish", aspect: 1.3, description: "Thick oval body with white base and black irregular spots." },
  { name: "Yellowfin Tuna", shape: "tuna", aspect: 1.6, description: "Powerful streamlined body with bright yellow fins." },
  { name: "Hammerhead Ray", shape: "hammerheadRay", aspect: 1.1, description: "Broad flattened ray body with an extremely wide hammer-shaped head." },
  { name: "Blobfish", shape: "blobfish", aspect: 1.0, description: "Soft rounded body with a large drooping face and minimal fins." },
  { name: "Fire Goby", shape: "fireGoby", aspect: 1.4, description: "Small slender body with white front and bright red-orange rear." },
  { name: "Blue Marlin", shape: "marlin", aspect: 1.8, description: "Long muscular body with an extremely long pointed bill." },
  { name: "Butterflyfish", shape: "butterflyfish", aspect: 1.2, description: "Small compressed body with vertical black eye stripe." },
  { name: "Goblin Shark", shape: "goblinShark", aspect: 1.7, description: "Long pale body with an extremely elongated snout and protruding jaw." },
  { name: "Cookiecutter Shark", shape: "cookiecutterShark", aspect: 1.5, description: "Small cylindrical body with glowing underside and bioluminescent collar." },
  { name: "Flying Squid", shape: "flyingSquid", aspect: 1.5, description: "Streamlined squid body with huge wing-like fins." },
  { name: "Giant Clam", shape: "clam", aspect: 1.2, description: "Massive colorful shell with wavy mantle edges." },
  { name: "Leafy Goblinfish", shape: "leafyGoblinfish", aspect: 1.3, description: "Irregular camouflage body with leaf-like skin appendages." },
  { name: "Blue-Ringed Octopus", shape: "blueRingedOctopus", aspect: 1.1, description: "Small rounded mantle with brilliant blue rings across body." },
  { name: "Ribbon Eel", shape: "ribbonE Eel", aspect: 2.2, description: "Extremely thin elongated body with a long ribbon-like tail." },
  { name: "Giant Oarfish", shape: "oarfish", aspect: 2.5, description: "Extremely long ribbon-shaped body with metallic silver scales." },
  { name: "Deepsea Dragonfish", shape: "dragonfish", aspect: 1.8, description: "Long black body with oversized head and glowing photophores." },
  { name: "Celestial Phoenix Fish", shape: "phoenixFish", aspect: 1.6, description: "Majestic celestial silhouette with long flowing golden tail." },
  { name: "Cosmic Nebula Fish", shape: "cosmicNebula", aspect: 1.2, description: "Elegant fish-shaped body made of deep-space colors and star particles." },
  { name: "Abyssal Crystal Dragonfish", shape: "crystalDragonfish", aspect: 1.6, description: "Ancient underwater creature with transparent crystal-like fins and horns." },
  { name: "Aurora Phantom Fish", shape: "auroraPhantom", aspect: 1.3, description: "Mysterious spectral fish with flowing aurora colors inside its body." },
  { name: "Timewarp Leviathan", shape: "timewarpLeviathan", aspect: 1.8, description: "A creature that exists outside normal time with glowing temporal rings." },
  { name: "Infinite Ocean Godfish", shape: "oceanGodfish", aspect: 1.6, description: "Ultimate Divine fish with enormous celestial fins and underwater stars." },
];

export const INITIAL_SKINS: FishSkin[] = Object.keys(SKIN_DATA).map((id, index) => {
  const profile = speciesProfiles[index] || { name: `Exotic Species #${index + 1}`, shape: "standard", aspect: 1.2, description: "A rare and mysterious underwater species." };
  return {
    id,
    name: profile.name,
    price: index === 0 ? 0 : index * 300,
    unlocked: index === 0,
    shape: profile.shape,
    colors: SKIN_DATA[id],
    rarity: SKIN_DATA[id].rarity,
    aspectMultiplier: profile.aspect,
    description: profile.description
  };
});
