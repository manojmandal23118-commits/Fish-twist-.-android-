export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  password?: string;
  tags: string[];
  keywords: string[];
  categories: string[];
  uploadDate: string;
  isNsfw: boolean;
}

export interface UserState {
  isVerified: boolean;
  isOwner: boolean;
}