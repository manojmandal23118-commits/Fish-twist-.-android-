
import type { Video } from './types';

export const MOCK_VIDEOS: Video[] = [];
