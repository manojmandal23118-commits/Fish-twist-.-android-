# **App Name**: Private Reels

## Core Features:

- Secure Owner Login: Exclusive authentication for the designated owner to access upload and content management functionalities.
- Owner Video Upload & Metadata: Ability for the owner to upload video files and define associated metadata, including a specific password for viewing each video.
- Password-Protected Video Playback: Require users to enter a correct, video-specific password to unlock and stream video content.
- Age Verification Gate (18+): Display a prominent age confirmation screen requiring users to verify they are 18 years or older before accessing any content on the site.
- Responsive Video Display & Browsing: A user interface for browsing available videos and playing streams, similar to popular video platforms, optimized for various screen sizes and devices.
- AI-Assisted Video Tagging Tool: An AI tool that suggests relevant tags, keywords, and categorizations for uploaded videos, based on the owner's provided textual description, to improve content organization.
- Scalable Video Delivery: Implementation of video streaming infrastructure designed to efficiently deliver content to a potentially large number of concurrent viewers without performance degradation.

## Style Guidelines:

- Primary color: Muted Indigo/Slate Blue (#364E77), chosen for its association with technology, security, and a sophisticated, professional aesthetic in a dark scheme.
- Background color: A very dark blue-grey (#1C1E22), subtly matching the primary hue but heavily desaturated to create a sleek, unobtrusive backdrop suitable for video content.
- Accent color: Bright Sky Blue (#6BD4EC), an analogous hue providing a distinct, clear contrast against the darker palette, used for interactive elements and highlights to guide user attention.
- Headline and body font: 'Inter' (sans-serif), chosen for its modern, clean, and highly readable design, ensuring clarity and an objective feel across all text elements.
- Utilize minimalist and clean line icons for a contemporary feel, focusing on clear communication for video controls, security (lock icons), and navigation.
- Employ a content-focused grid layout for video listings, with distinct areas for video playback, user controls, and an explicit, clear age verification prompt, prioritizing discoverability and immersive viewing.
- Incorporate subtle and smooth animations for transitions, video loading states, and interactive elements like password input fields, enhancing the user experience without distraction.